# docs/DATA_MODEL.md · Kasuwa · EXAMPLE

## Things (what Kasuwa remembers)
| Thing | ID | Key fields (example) | Links | Used by scenarios |
|---|---|---|---|---|
| Seller | seller_id S014 | shop_name "Ngozi's Wears", area "Yaba", verified true, best_seller true | 1 seller → many products, orders | S1–S5, A2 |
| Buyer | buyer_id B021 | name "Kemi A." (invented), area "Wuse", joined_on 2026-10-03 | 1 buyer → many orders, messages | B1–B5 |
| Product | product_id P042 | title "Power bank", category, price 12500 (number), stock 8 | belongs to 1 seller | B1, S1, S2 |
| Order | order_id O0310 | qty 1, total 12500, status paid / shipped / delivered / cancelled / returned, ordered_on, commission 1000, came_from search / ad_notification / shared_link / home_feed | 1 buyer, 1 seller, 1 product | B1, B5, S3, A1 |
| Message | message_id M0101 | question, sent_on, replied true, reply_hours 3 | buyer ↔ seller about a product | B2, S4 |

## Events (things that happen; needed for stats)
| Event | Fields | Used for |
|---|---|---|
| Share | channel whatsapp, opened | B3: orders from shared links |
| Notification | campaign, opened, clicked | B4, A4: open rate, click rate |
| Status change | order_id, new status, date | S3: days from paid to delivered |

## Numbers for each role (calculated, never typed)
| Role | Number | How to count | Day / week / month |
|---|---|---|---|
| Seller | my sales (₦) | sum of total, my delivered orders | ✓ |
| Seller | fees paid to Kasuwa | sum of commission, my orders | ✓ |
| Seller | stock left · out of stock | sum of stock · count stock = 0 | – |
| Admin | GMV | sum of total, delivered orders | ✓ |
| Admin | commission earned | sum of commission | ✓ |
| Admin | new buyers · new products | count by joined_on / listed_on | ✓ |
| Admin | reply rate | replied ÷ messages | ✓ |

## Rules
Money = whole naira as a number. Dates = YYYY-MM-DD. Commission = 8% of delivered orders only. No phone numbers or addresses. Everything labelled MOCK.

## How we built this (the 5 steps, chain C3)
1. Nouns → things: buyer, product, order, seller.
2. Actions → status or event with a date and who: order.status paid → shipped → delivered, ordered_on.
3. Screens → fields: product page shows title, price, stock; seller orders screen shows qty, total, status.
4. IDs and links: order has buyer_id, seller_id, product_id.
5. Numbers per role: seller sales, fees; admin GMV, commission (table above).

## Mock data plan (Lab 3)
| Decide | Kasuwa |
|---|---|
| How many | 20 sellers · 200 buyers · 120 products · 520 orders · 160 messages · 130 shares · 400 notifications |
| Rules | prices by category (DATA_SOURCES.md) · 74% delivered, 8% shipped, 5% paid, 8% cancelled, 5% returned · commission 8% of delivered · about 80% of messages answered |
| Time | 1 Sep – 29 Nov 2026 (90 days), busier later |
| Messy cases | cancelled, returned, sold out (stock 0), unanswered messages |
| Check | counts · 5 random rows · orders per month (Sep 104 · Oct 190 · Nov 226) |
