# Lab 3 · Step 5–6 · See your data, then talk as a team · EXAMPLE (Kasuwa)

## Step 5 · The prompt (copy it, change nothing except the words in < >)

```
Make data/check.html so I can SEE my mock data. It must open by double-click
(load data/mock_data.js, no server, no install, plain HTML and JavaScript).
Put a red "MOCK DATA" label at the top. Show:
1. a count card for every thing and event in my data
2. a bar chart of <orders> per week over the 90 days, and the total per month
3. the mix of <order status> and of <where orders came from>, with % for each
4. one box per role (<buyer>, <seller>, admin) with the key numbers from
   docs/DATA_MODEL.md "Numbers per role" (for the seller: top 5 by sales)
5. a "Plan vs data" table: each rule in my Mock data plan, the planned value,
   the value in the data, and yes / check
6. 10 random records as a table, with names instead of IDs
Do not change the data or the script. Then tell me 3 things that look wrong or fake.
```

Open `data/check.html` in your browser. The Kasuwa result is `21p_data_check.html` in this folder (double-click it).

## Step 6 · Team talk (12 min, your Week 1 team of 3)

Each person shows their check page for 2 minutes. Then talk about these 3 questions for each product:

| # | Question | Look at |
|---|---|---|
| 1 | **Is it what I planned?** Counts, %, months busier later | "Plan vs data" table, month totals |
| 2 | **Would an investor believe it?** Prices, order sizes, growth, messy cases, every role has data | 10 random rows, the role boxes, the biggest and smallest values |
| 3 | **Can it tell a story on Thursday?** Is there one number per role you would show? | Role boxes, weekly chart |

Each owner writes **1–2 fixes** to make. Fix the plan or the script, never the data by hand (step 7).

## What the Kasuwa team found (example)

| What they saw | Problem? | Fix (plan or script) |
|---|---|---|
| Orders grow 104 → 190 → 226 per month; every rule says "✓ yes" | No, as planned | – |
| Order O0167: a **Phone case for ₦169,200** (×3 = ₦507,600) | Yes: the script picks a price from the whole category range (₦2,000–180,000), so a phone case can cost as much as a phone | Script: give each item its own price range in data/seed/ |
| Average delivered order ₦42,822, but half of all orders are under ₦18,000 | Partly: a few huge orders pull the average up | Show the median too, after fixing the prices above |
| The top seller (Chioma's Corner) has no Best seller ★ | No: Best seller is only for Verified sellers (badge rule) | Write the rule under the table so investors don't ask |
| 30% of ad notifications opened, 10% clicked | Not sure: is that real for Nigeria? | DATA_SOURCES.md: mark it "assumption" and ask 3 people on Monday |

DEC-07 · Fix product prices per item in the seed list; run the script again; commit. (Kasuwa, Day 5)
