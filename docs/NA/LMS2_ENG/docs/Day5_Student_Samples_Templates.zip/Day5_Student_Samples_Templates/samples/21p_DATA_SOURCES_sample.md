# docs/DATA_SOURCES.md · Kasuwa · EXAMPLE

| Number | Value used | Source | Type |
|---|---|---|---|
| Price ranges per category | phones ₦2,000–180,000, fashion ₦3,000–25,000… | competitor apps (public listings, 20 products checked) | observed |
| Commission | 8% | typical marketplace fees, competitor seller pages | benchmark |
| Orders delivered | about 74% | guess, checked with 3 shop owners | assumption |
| Messages answered | about 80% | 5 sellers asked how fast they reply | observed (small) |
| Notification open rate | about 30% | typical push open rates | benchmark |
| Orders from shared links | about 15% | guess: WhatsApp sharing is common | assumption |

## Seed lists (data/seed/)
In this example the seed lists sit at the top of the script (20 first names, 10 areas, 5 categories with price ranges and items). In your product, keep them as small CSV files in data/seed/.

## Period
90 days (1 Sep – 29 Nov 2026), more activity later, so day / week / month charts show growth.
