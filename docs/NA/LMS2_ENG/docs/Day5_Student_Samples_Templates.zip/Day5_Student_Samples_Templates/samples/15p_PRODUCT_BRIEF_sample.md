# docs/PRODUCT_BRIEF.md · Kasuwa · EXAMPLE (draft, Day 5)

**What it is:** an online market where small Nigerian shops sell to buyers in their city, with WhatsApp-style chat.
**Who uses it:** buyers (young workers in Lagos and Abuja) · sellers (small shops, 1–3 people) · the Kasuwa team (admin).
**Problem:** buyers can't compare small shops or trust them; sellers sell only to people who walk past or follow them on WhatsApp.
**Key action:** a buyer finds a product, asks the seller a question, and pays; the seller ships and updates the status.
**How it earns:** 8% commission on each delivered order · later: paid ads for sellers (promoted products).
