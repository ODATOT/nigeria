"""Kasuwa (fictional marketplace) mock data generator. EXAMPLE for Day 5 Lab 3.
Reads nothing secret, writes data/mock_data.json and data/mock_data.js. Fixed seed: same data every run.
All people are invented. No phone numbers or addresses."""
import json, random, os
from datetime import date, timedelta
SEED = 7
random.seed(SEED)
START, DAYS = date(2026, 9, 1), 90          # 90 days -> daily, weekly, monthly stats
COMMISSION = 0.08                             # platform fee: 8% of each delivered order
FIRST = ["Ada","Chidi","Tunde","Ngozi","Bola","Emeka","Fatima","Musa","Kemi","Ifeanyi","Zainab","Segun","Amaka","Yusuf","Funke","Obinna","Halima","Dayo","Chioma","Ibrahim"]
AREAS = ["Ikeja","Yaba","Surulere","Lekki","Wuse","Garki","Maitama","Gwarinpa","Aba","Onitsha"]
CATS = {"Fashion": (3000, 25000), "Phones & accessories": (2000, 180000), "Beauty": (1500, 12000), "Home & kitchen": (2500, 40000), "Food & drinks": (800, 9000)}
ITEMS = {"Fashion": ["Ankara dress","Aso oke cap","Leather slides","Agbada set","Kaftan"], "Phones & accessories": ["Phone case","Power bank","Earbuds","Used smartphone","Charger"],
         "Beauty": ["Shea butter","Black soap","Hair cream","Perfume oil","Lip gloss"], "Home & kitchen": ["Pot set","Blender","Plastic chairs","Bedsheet","Rechargeable fan"],
         "Food & drinks": ["Garri 5kg","Palm oil 2L","Zobo pack","Plantain chips","Honey 1L"]}
def d(i): return (START + timedelta(days=i)).isoformat()
def name(): return random.choice(FIRST) + " " + random.choice("ABCDEFGHIKLMNOSTU") + "."
# growth: more sign-ups and orders later in the 90 days
def day_weighted(): return int(DAYS * random.random() ** 0.7)

sellers = []
for i in range(1, 21):
    joined = random.randint(0, 40)
    sellers.append({"seller_id": f"S{i:03d}", "shop_name": f"{random.choice(FIRST)}'s {random.choice(['Store','Wears','Gadgets','Corner','Hub'])}",
                    "area": random.choice(AREAS), "joined_on": d(joined), "verified": random.random() < 0.45, "best_seller": False})
seen = {}
for s in sellers:                      # make shop names unique (no extra random calls)
    n = s["shop_name"]; seen[n] = seen.get(n, 0) + 1
    if seen[n] > 1: s["shop_name"] = n + " " + s["area"]
buyers = [{"buyer_id": f"B{i:03d}", "name": name(), "area": random.choice(AREAS), "joined_on": d(day_weighted())} for i in range(1, 201)]
products = []
for i in range(1, 121):
    s = random.choice(sellers); cat = random.choice(list(CATS)); lo, hi = CATS[cat]
    products.append({"product_id": f"P{i:03d}", "seller_id": s["seller_id"], "category": cat, "title": random.choice(ITEMS[cat]),
                     "price": round(random.randint(lo, hi), -2), "stock": random.choice([0, 0, 2, 5, 8, 12, 20, 35]),
                     "listed_on": d(random.randint(int(s["joined_on"][8:]) if s["joined_on"] < d(31) else 0, 60))})
STATUS = [("delivered", .74), ("shipped", .08), ("paid", .05), ("cancelled", .08), ("returned", .05)]
def pick(opts):
    r, acc = random.random(), 0
    for k, p in opts:
        acc += p
        if r < acc: return k
    return opts[-1][0]
orders = []
for i in range(1, 521):
    day = day_weighted(); p = random.choice(products); qty = random.choice([1, 1, 1, 2, 3])
    st = pick(STATUS)
    if day > DAYS - 4 and st == "delivered": st = random.choice(["paid", "shipped"])   # recent orders not delivered yet
    total = p["price"] * qty
    orders.append({"order_id": f"O{i:04d}", "buyer_id": random.choice(buyers)["buyer_id"], "seller_id": p["seller_id"], "product_id": p["product_id"],
                   "qty": qty, "total": total, "status": st, "ordered_on": d(day),
                   "commission": round(total * COMMISSION) if st == "delivered" else 0, "came_from": pick([("search", .5), ("ad_notification", .15), ("shared_link", .15), ("home_feed", .2)])})
messages = []
for i in range(1, 161):
    day = day_weighted(); p = random.choice(products); replied = random.random() < 0.8
    messages.append({"message_id": f"M{i:04d}", "buyer_id": random.choice(buyers)["buyer_id"], "seller_id": p["seller_id"], "product_id": p["product_id"],
                     "question": random.choice(["Is this still available?", "Can you deliver to " + random.choice(AREAS) + "?", "Do you have another colour?", "Last price?", "How many days for delivery?"]),
                     "sent_on": d(day), "replied": replied, "reply_hours": random.choice([1, 2, 3, 5, 8, 24]) if replied else None})
shares = [{"share_id": f"SH{i:04d}", "buyer_id": random.choice(buyers)["buyer_id"], "product_id": random.choice(products)["product_id"],
           "channel": pick([("whatsapp", .7), ("instagram", .15), ("copy_link", .15)]), "shared_on": d(day_weighted()), "opened": random.random() < 0.4} for i in range(1, 131)]
notifications = []
for i in range(1, 401):
    opened = random.random() < 0.3
    notifications.append({"notification_id": f"N{i:04d}", "buyer_id": random.choice(buyers)["buyer_id"], "campaign": random.choice(["Weekend sale", "New phones", "Free delivery Lagos"]),
                          "sent_on": d(day_weighted()), "opened": opened, "clicked": opened and random.random() < 0.35})
# best seller rule (automatic): top 3 sellers by delivered sales in the last 30 days, and verified
recent = {}
for o in orders:
    if o["status"] == "delivered" and o["ordered_on"] >= d(DAYS - 30): recent[o["seller_id"]] = recent.get(o["seller_id"], 0) + o["total"]
top = [s for s in sorted(recent, key=recent.get, reverse=True) if next(x for x in sellers if x["seller_id"] == s)["verified"]][:3]
for s in sellers: s["best_seller"] = s["seller_id"] in top
data = {"_note": "MOCK DATA for a demo. All people and shops are invented. Generated by tools/make_mock_data.py, seed %d." % SEED,
        "commission_rate": COMMISSION, "period": {"from": d(0), "to": d(DAYS - 1)},
        "sellers": sellers, "buyers": buyers, "products": products, "orders": orders, "messages": messages, "shares": shares, "notifications": notifications}
os.makedirs("data", exist_ok=True)
json.dump(data, open("data/mock_data.json", "w"), indent=1, ensure_ascii=False)
open("data/mock_data.js", "w").write("window.MOCK = " + json.dumps(data, ensure_ascii=False) + ";\n")
print({k: len(v) for k, v in data.items() if isinstance(v, list)})
dl = [o for o in orders if o["status"] == "delivered"]
print("GMV delivered", sum(o["total"] for o in dl), "commission", sum(o["commission"] for o in dl), "best sellers", top)
