# docs/SCENARIOS.md · Kasuwa · EXAMPLE

> One scenario = one role, one goal, the steps, the screens, the data it touches, and the number that shows it worked.
> ★ = key scenario for the Thursday demo (at least 2 per role).

## Roles
| Role | Who | Wants |
|---|---|---|
| Buyer | a young worker in Lagos or Abuja | find a good product from a shop they can trust |
| Seller | a small shop owner | sell more without standing in the market all day |
| Admin | the Kasuwa team (you) | grow the market, keep it safe, earn commission |

## Buyer
| # | Scenario | Trigger | Steps (screens) | Data touched | Success number |
|---|---|---|---|---|---|
| B1 ★ | Find, cart, pay | wants a power bank | Search → product page → Add to cart → Cart → Pay → Order confirmed | product, cart, order (status "paid") | search → order rate |
| B2 ★ | Ask a seller | not sure of delivery | Product page → "Message seller" → My messages (history) → sees reply | message (sent, replied, reply time) | % of messages answered in 24 h |
| B3 | Share with a friend | likes a dress | Product page → Share → WhatsApp link → friend opens | share (channel, opened) | orders that came from a shared link |
| B4 | Ad notification | "Weekend sale" | Notification → sale page → product → order | notification (opened, clicked), order.came_from | open rate, click rate |
| B5 | Track my order | waiting | My orders → order → status timeline | order.status | – |

## Seller
| # | Scenario | Trigger | Steps (screens) | Data touched | Success number |
|---|---|---|---|---|---|
| S1 ★ | List a product | new stock | Seller console → Add product → title, category, price, stock, photo → Publish | product | products listed per seller |
| S2 | Change price or stock | price went up | My products → edit → save | product.price, product.stock | – |
| S3 ★ | Ship an order | new order | Orders (new) → open → "Shipped" → "Delivered" | order.status + date | time from paid to delivered |
| S4 | Answer a buyer | new message | Inbox → read → reply | message.replied, reply_hours | reply rate |
| S5 | See my business | end of week | My stats → sales, fees paid to Kasuwa, stock left, best products (day / week / month) | orders, commission, stock | weekly sales (₦) |

## Admin
| # | Scenario | Trigger | Steps (screens) | Data touched | Success number |
|---|---|---|---|---|---|
| A1 ★ | Morning check | every day | Admin dashboard → sign-ups, new products, orders, GMV, commission (day / week / month charts) | all | GMV, commission |
| A2 ★ | Give badges | weekly | Sellers → sort by sales and reply rate → "Verified" (admin approves) · "Best seller" (automatic: top 3 by 30-day sales, verified only) | seller.verified, seller.best_seller | % of orders from badged sellers |
| A3 | Handle a problem | buyer reports a seller | Sellers → seller → orders + messages → warn or pause | seller.status | – |
| A4 | Send a campaign | slow week | Campaigns → new → audience → send → results | notification | click → order rate |

## Connected scenarios (one action, seen by other roles)
| # | Chain | Screens it touches |
|---|---|---|
| C1 ★ | Buyer signs up → admin sees +1 new buyer today | sign-up → Admin overview |
| C2 ★ | Seller lists a product (S1) → admin sees products listed +1 and the new product → buyers find it in search | Seller · Add product → Admin overview → Buyer search |
| C3 ★ | Buyer pays (B1) → seller sees a new order and marks it shipped (S3) → admin sees the order and the status change → buyer tracks it (B5) | Buyer pay → Seller orders → Admin overview → Buyer my orders |
| C4 | Buyer messages a seller (B2) → seller replies (S4) → admin sees the reply rate | Product page → Seller inbox → Admin sellers |

Thursday demo follows C3: the same order appears on three screens.

## For content apps (TikTok / YouTube type): add an Advertiser role
| # | Scenario | Steps | Data | Number |
|---|---|---|---|---|
| AD1 | Create a campaign | Ads → new → budget, audience, video → submit → admin approves | campaign, budget | – |
| AD2 | See results | Ads → campaign → views, clicks, cost per click (day / week) | impressions, clicks, spend | cost per click |
