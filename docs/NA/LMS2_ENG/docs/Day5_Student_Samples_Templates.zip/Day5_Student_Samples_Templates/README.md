# Day 5 · Users, scenarios and data · samples and templates

**samples/**: a worked example for Kasuwa, a fictional marketplace. Read them, don't copy them. The number at the start of each name is the slide where it is used.
- 15p_PRODUCT_BRIEF_sample.md, 15p_SCENARIOS_sample.md: Lab 1 (roles, scenarios with ★, connected chains)
- 18p_DATA_MODEL_sample.md: Lab 2 (things, events, numbers per role) and the Mock data plan for Lab 3
- 21p_DATA_SOURCES_sample.md, 21p_make_mock_data.py, 21p_mock_data_sample.json: Lab 3 (sources, generator script with a fixed seed, 90 days of MOCK data)
- 21p_DATA_CHECK_sample.md: Lab 3 steps 5-6, the prompt that makes a visual check page, the 3 team-talk questions, and what the Kasuwa team found
- 21p_data_check.html (+ 21p_mock_data_sample.js): the check page itself. Double-click it to see the Kasuwa data as charts and tables

**templates/**: blank forms to fill for your own product. Save them in your project's docs/ folder without the word "template" (for example docs/SCENARIOS.md).

All people, shops and numbers in the samples are invented (MOCK).
