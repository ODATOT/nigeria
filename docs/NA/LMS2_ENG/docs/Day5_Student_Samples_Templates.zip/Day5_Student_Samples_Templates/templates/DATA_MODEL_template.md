# docs/DATA_MODEL.md · <your product> · <your name>

## Things (what my product remembers)
| Thing | ID | Key fields (example value) | Links | Used by scenarios |
|---|---|---|---|---|
| | | | | |

## Events (things that happen; each needs a date and who)
| Event | Fields | Used for |
|---|---|---|
| | | |

## Numbers for each role (calculated, never typed)
| Role | Number | How to count | Day / week / month |
|---|---|---|---|
| | | | |

## Rules
Money = whole naira as a number · dates = YYYY-MM-DD · no real people, no phone numbers · everything labelled MOCK

## Mock data plan (Lab 3)
- period: 90 days, busier later
- how many of each thing:
- messy cases (about 15%):
