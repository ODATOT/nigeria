# docs/PRODUCT_BRIEF.md · <product> · <your name>

**What it is:** <one sentence>
**Who uses it:** <role 1> · <role 2> · me (admin) · (<advertiser>, if a content app)
**Problem:** <what is hard today, for whom>
**Key action:** <the one thing a user does that matters most>
**How it earns:** <who pays, how much, when>
