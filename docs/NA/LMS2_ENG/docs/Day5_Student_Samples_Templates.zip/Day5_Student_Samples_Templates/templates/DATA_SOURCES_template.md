# docs/DATA_SOURCES.md · <your product> · <your name>

| Number my mock data needs | Value I use | Source | Type (observed / public source / assumption) |
|---|---|---|---|
| | | | |
