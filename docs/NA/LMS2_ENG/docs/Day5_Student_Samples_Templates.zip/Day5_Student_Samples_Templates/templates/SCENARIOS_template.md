# docs/SCENARIOS.md · <product> · <your name>

> ★ = key scenario for the Thursday demo (at least 2 per role).

## Roles
| Role | Who | Wants |
|---|---|---|
| | | |

## <Role 1>
| # | Scenario | Trigger | Steps (screens) | Data touched | Success number |
|---|---|---|---|---|---|
| ★ | | | | | |
| ★ | | | | | |
| | | | | | |

## <Role 2>
| # | Scenario | Trigger | Steps (screens) | Data touched | Success number |
|---|---|---|---|---|---|
| ★ | | | | | |
| ★ | | | | | |

## Admin (you)
| # | Scenario | Trigger | Steps (screens) | Data touched | Success number |
|---|---|---|---|---|---|
| ★ | Morning check | every day | | | |
| ★ | | | | | |

## Connected scenarios (one action, seen by other roles)
| # | Chain (role acts → who else sees what) | Screens it touches |
|---|---|---|
| ★ | | |
| ★ | | |
