# 23p_REVIEW_QA_sample.md — One fix, three builds · YouTube "SkillView" EXAMPLE

> Example for Lab 5 (slide 23). Blank form: `../templates/23p_REVIEW_QA_template.md`.
> The team chose ONE decision to build: **DEC-002 "no next video" screen**. Each person built it in their own folder.
>
> **How to write (each person fills one column, then the team decides, 7 min)**
> 1. Top line: the ONE DEC the team chose to build.
> 2. **Files changed:** after building, type `git diff --stat` and copy the numbers.
> 3. **Surprises:** anything in the diff you didn't ask for (a login, a new library, a deleted file)?
> 4. **/review issues:** what it fixed by itself and what it asked you; what you approved.
> 5. **/qa-only:** how many Given/When/Then lines passed (e.g. 3 of 4) and what failed.
> 6. Together: keep the build with most passes and fewest surprises. New problems become a new DEC.

| | Ada (Claude Code) | Tunde (Codex) | Chidi (Claude Code) |
|---|---|---|---|
| Files changed (git diff) | 2 files, +38 −4 | 3 files, +71 −10 | 2 files, +29 −2 |
| Surprises in the diff | none | added a "Sign in" link → rejected | none |
| /review issues | 1 auto-fixed, 1 asked | 2 asked | 1 asked |
| /qa-only: Done-when passed | F1-1 ✓ F1-2 ✓ F1-3 ✓ | F1-1 ✓ F1-2 ✗ F1-3 ✓ | F1-1 ✓ F1-2 ✓ F1-3 ✓ |
| Other QA notes | title overflow on video 7 | Cancel didn't stop the timer | title overflow on video 7 |

**Kept:** Chidi's build: all 3 checks pass, smallest diff, nothing extra. Ada's is equal; Chidi's diff is easier to read.
**Logged:** DEC-005 (title overflow, both QA reports found it).
**What we learned:** the build that added a "Sign in" link was the one where the prompt didn't say "only DEC-002". The wording matters.
