# 20p_DECISION_LOG_sample.md — Team decisions · YouTube "SkillView" EXAMPLE

> Example for Lab 4 (slide 20). Blank form: `../templates/20p_DECISION_LOG_template.md`.
> One block per decision. **Why** must point to evidence (OBS, EXP, a review finding, a test). "Because AI said so" is not a reason.
>
> **How to write (team, 20 min · Product lead types, everyone checks)**
> 1. Take every **accept** and **change** row from PLAN_REVIEW.md. Each becomes one DEC block (3–5 in total).
> 2. **Title:** the decision in one line, starting with a verb (Cut…, Add…, Stop…).
> 3. **Why:** point to evidence: OBS-###, EXP-###, review finding #, or a test result.
> 4. **Owner:** one person's name. **Review:** when you will check it again (after Lab 5, tomorrow, before demo).
> 5. Then open `docs/PRD_BM.md`, change only what the DECs say, and add the DEC tag on each changed line.
> 6. Rewrite each "Done when" as Given / When / Then. Test: could two people judge it the same way?

**DEC-001 · Cut F2 (subscribe) from this version**
- Why: CEO review (finding 1) + only one OBS (OBS-006); F1 is the narrowest test of EXP-001
- Owner: Tunde (Product lead) · Review: after Lab 5 test

**DEC-002 · Add a "no next video" screen to F1**
- Why: Design review rated states 4/10 (finding 3); a real viewer reaches the end of the list
- Owner: Ada (Evidence lead) · Review: /qa-only result

**DEC-003 · Cancel stops the timer, and the timer stops when the page is hidden**
- Why: Eng review (finding 6); F1 Done when
- Owner: Chidi (Tech lead) · Review: /review result

**DEC-004 · No watch history or login in the POC**
- Why: hidden part C (no data) and B (AI's usual pattern); "What we fake" in PRD_BM
- Owner: Tunde · Review: before investor demo

**DEC-005 · Long titles overflow on video 7 at 360px (found by /qa-only)**
- Why: QA report, repro "open video 7"
- Owner: Chidi · Review: tomorrow morning (fix with /qa)
