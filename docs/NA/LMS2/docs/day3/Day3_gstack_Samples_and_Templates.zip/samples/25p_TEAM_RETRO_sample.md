# 25p_TEAM_RETRO_sample.md — Team retro · YouTube "SkillView" EXAMPLE

> Example for Lab 6 (slide 25). Blank form: `../templates/25p_TEAM_RETRO_template.md`.
>
> **How to write (team, 15 min · each person opens their own GSTACK_LOG)**
> 1. Talk for 10 minutes using the questions below. Each answer must point to a log entry or a DEC.
> 2. Write for 5 minutes: finish the 3 lesson sentences at the bottom.
> 3. One person reads them aloud to the class.

**Agree:** all three /office-hours runs said "costly data is an assumption" → we kept F1 but wrote it as a hypothesis (DEC-001 notes).
**Disagree:** two runs said cut F3 (share), one said keep it → we kept it because OBS-009 is a fact we observed.
**Rejected:** login and watch history (DEC-004): AI's usual pattern and a hidden part we can't copy.
**Claude Code vs Codex:** Claude Code asked multiple-choice questions; Codex asked in plain chat and its build added a "Sign in" link we didn't ask for.

## Our 3 lessons
1. When all three office-hours runs said "costly data is an assumption", we made F1 smaller and tested it first (DEC-001).
2. We rejected login because it was not in PRD_BM and no OBS asked for it (DEC-004).
3. Compared with Day 2, gstack caught the "no next video" screen and the running timer **before** a user did (DEC-002, DEC-003).
