# 18p_PLAN_REVIEW_sample.md — Team merge of 3 plan reviews · YouTube "SkillView" EXAMPLE

> Example for Lab 3 (slide 18). Blank form: `../templates/18p_PLAN_REVIEW_template.md`.
> Each person ran ONE review on the same `docs/PRD_BM.md`. Each brings their top 3. The team marks each row.
> **Team says:** accept · change (how?) · reject (why?)
>
> **How to write (team, 10 min · Product lead runs the meeting, Tech lead types)**
> 1. Fill the first table: who ran which review, and the main choice they made when AI asked.
> 2. Each person reads out their **top 3 findings** (from their GSTACK_LOG entry 2). Type one row each.
> 3. **Evidence it points to:** an OBS, EXP, Done-when line or score. No evidence? Write "none".
> 4. Decide each row together: **accept** · **change** (say how) · **reject** (say why: A/B/C from COMPARE is a good reason).
> 5. Last 2 lines: where the lenses agreed, and where they disagreed and what you chose.

| Who | Skill | Mode / main choice |
|---|---|---|
| Tunde (Product lead) | /plan-ceo-review | Reduction (one-day POC) |
| Ada (Evidence lead) | /plan-design-review | Fix gaps only |
| Chidi (Tech lead) | /plan-eng-review | Plain HTML/JS, sample data |

| # | Finding | From | Evidence it points to | Team says |
|---|---|---|---|---|
| 1 | Cut F2 (subscribe) from this version | CEO | Only OBS-006; F1 tests EXP-001 directly | accept |
| 2 | Success number = 2nd-video rate only | CEO | EXP-001 | accept |
| 3 | Add "no next video" screen | Design | States 4/10 | accept |
| 4 | Cancel button 44px, easy for a thumb | Design | 360px phone (Done when) | accept |
| 5 | Long titles: cut at 2 lines | Design | 360px phone | change: 2 lines + "…" |
| 6 | Cancel must stop the timer; clear it when leaving the page | Eng | F1 Done when | accept |
| 7 | 5 test cases for the countdown | Eng | F1 | accept (become Given/When/Then) |
| 8 | Save watch history to recommend better | Eng | OBS-007 | reject: hidden part C (no data in a POC) |
| 9 | Add login so subscribe syncs | CEO | — | reject: not in PRD, AI's usual pattern (B) |

**Where the 3 lenses agreed:** F1 is the core; keep it small.
**Where they disagreed:** CEO wanted F2 cut, Eng planned it in detail → team chose CEO (DEC-001).
