# Day 3 · gstack labs · YouTube "SkillView" EXAMPLES — blank forms are in ../templates/

The examples continue the Day 2 YouTube example (SkillView). Your team uses its OWN Day 2 files.
AI quotes in the examples are illustrations: your AI's answers will be different.

| Lab · slide | Example (filled) | Blank form | Who |
|---|---|---|---|
| Lab 1 · slide 14 | — (install + git save point) | — | each person |
| Lab 2 · slide 16 | 16p_GSTACK_LOG_sample.md (entry 1) | 16p_GSTACK_LOG_template.md | each person |
| Lab 3 · slide 18 | 16p_GSTACK_LOG_sample.md (entry 2) + 18p_PLAN_REVIEW_sample.md | 18p_PLAN_REVIEW_template.md | each person → team |
| Lab 4 · slide 20 | 20p_DECISION_LOG_sample.md + 20p_PRD_BM_v2_sample.md | 20p_DECISION_LOG_template.md | team |
| Lab 5 · slide 23 | 16p_GSTACK_LOG_sample.md (entry 3) + 23p_REVIEW_QA_sample.md | 23p_REVIEW_QA_template.md | each person → team |
| Lab 6 · slide 25 | 25p_TEAM_RETRO_sample.md | 25p_TEAM_RETRO_template.md | team |
