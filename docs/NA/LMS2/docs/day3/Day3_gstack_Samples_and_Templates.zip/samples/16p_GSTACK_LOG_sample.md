# 16p_GSTACK_LOG_sample.md — My gstack log · YouTube "SkillView" EXAMPLE

> Example for Labs 2, 3 and 5 (slides 16, 18, 23). Blank form: `../templates/16p_GSTACK_LOG_template.md`.
> One file per person: `GSTACK_LOG_<yourname>.md`. One short entry each time you run a skill.
> The AI quotes below are illustrations. Your AI's words will be different. That's expected.
>
> **How to write (2–3 min after each skill run)**
> 1. **Prompt:** copy the first 2 lines of what you pasted.
> 2. **What AI said:** scroll to the end of the AI's answer and pick its 3 most important points. Write them in your own short words.
> 3. **Pass / fail:** tick the 3 boxes. All 3 ticked = PASS.
> 4. **My judgment:** for each point: accept, change, or reject, and *why* (point to an OBS, EXP or Done-when line).
> 5. **Files changed:** type `git status` and copy what it lists.
> Tip: you can ask the AI "Summarize your answer in 3 lines", but the judgment line must be yours.

**Name:** Ada (Evidence lead) · **Tool:** Claude Code desktop · **Team:** SkillView

---

## Entry 1 · /office-hours (Lab 2)

- **Prompt:** "Read docs/PRD_BM.md and research/OBS_LOG.md… Challenge our user, problem and 3 features. Don't change any files."
- **What AI said (3 lines):**
  1. "Costly data" is an assumption: no OBS shows a viewer stopping because of data.
  2. Narrowest first version = F1 only (countdown with length + Cancel).
  3. User is too wide: "small-business owner" → "shop owner who learns Excel on a phone in the evening".
- **Question that surprised me:** "What would your user do today if SkillView didn't exist?" (We never wrote the status quo.)
- **Pass / fail:** PASS: specific user ✓ · real pain ✓ · assumption to test ✓
- **My judgment:** accept the narrower user; keep F3 (share) because OBS-009 is strong evidence.
- **Files changed:** only `docs/OFFICE_HOURS_Ada.md` (checked with `git status`).

## Entry 2 · /plan-design-review (Lab 3)

- **My lens:** Design (Evidence lead)
- **Mode / choices I made:** asked to rate states → chose "fix gaps for a one-day POC"
- **Top 3 findings:**
  1. States 4/10: no screen for "no next video" or "offline".
  2. Video titles over 60 characters break the card at 360px.
  3. Cancel button too small for a thumb (needs 44px).
- **My judgment:** 1 and 3 accept, 2 change (cut titles at 2 lines instead of redesigning).

## Entry 3 · Build DEC-002 → /review → /qa-only (Lab 5)

- **Change asked:** add the "no next video" screen to F1 (DEC-002).
- **git diff:** 2 files (`index.html`, `app.js`), +38 / −4 lines.
- **/review:** [AUTO-FIXED] timer not cleared when the screen ends · [ASK] add keyboard focus to Cancel → I approved.
- **/qa-only:** F1 Given/When/Then 3 of 3 pass · new screen pass · 360px: long title overflows on video 7 (report only).
- **My judgment:** keep the build; the overflow goes to DECISION_LOG as DEC-005 for tomorrow.
