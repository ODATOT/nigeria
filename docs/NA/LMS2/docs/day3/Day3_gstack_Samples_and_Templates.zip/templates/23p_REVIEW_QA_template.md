# REVIEW_QA.md — One fix, three builds · BLANK (Lab 5, slide 23)

> Example: `../samples/23p_REVIEW_QA_sample.md`.
> The team picks ONE decision to build: **DEC-___ ______**. Each person builds it in their own folder.
>
> **How to write (each person fills one column, then the team decides, 7 min)**
> 1. Top line: the ONE DEC the team chose to build.
> 2. **Files changed:** after building, type `git diff --stat` and copy the numbers.
> 3. **Surprises:** anything in the diff you didn't ask for (a login, a new library, a deleted file)?
> 4. **/review issues:** what it fixed by itself and what it asked you; what you approved.
> 5. **/qa-only:** how many Given/When/Then lines passed (e.g. 3 of 4) and what failed.
> 6. Together: keep the build with most passes and fewest surprises. New problems become a new DEC.

| | ______ (tool: ____) | ______ (tool: ____) | ______ (tool: ____) |
|---|---|---|---|
| Files changed (git diff) | | | |
| Surprises in the diff | | | |
| /review issues | | | |
| /qa-only: Done-when passed | | | |
| Other QA notes | | | |

**Kept:** ______'s build, because ______
**Logged:** DEC-___ (new problem found)
**What we learned:**
