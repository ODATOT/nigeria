# TEAM_RETRO.md — Team retro · BLANK (Lab 6, slide 25)

> Example: `../samples/25p_TEAM_RETRO_sample.md`. Use all three GSTACK_LOG files.
>
> **How to write (team, 15 min · each person opens their own GSTACK_LOG)**
> 1. Talk for 10 minutes using the questions below. Each answer must point to a log entry or a DEC.
> 2. Write for 5 minutes: finish the 3 lesson sentences at the bottom.
> 3. One person reads them aloud to the class.

**Agree:** (where all three teammates' results said the same thing, and what we did)
**Disagree:** (where they differed, and whose evidence won)
**Rejected:** (which AI suggestion, and why)
**Claude Code vs Codex:** (if both used)

## Our 3 lessons
1. When all three office-hours runs said ______, we ______ (DEC-___).
2. We rejected ______ because ______.
3. Compared with Day 2, gstack caught ______ before we built it.
