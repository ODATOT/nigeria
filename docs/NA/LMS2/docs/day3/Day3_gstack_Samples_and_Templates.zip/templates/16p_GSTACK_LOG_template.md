# GSTACK_LOG_<yourname>.md — My gstack log · BLANK (Labs 2, 3, 5)

> Example: `../samples/16p_GSTACK_LOG_sample.md`. One short entry each time you run a skill.
>
> **How to write (2–3 min after each skill run)**
> 1. **Prompt:** copy the first 2 lines of what you pasted.
> 2. **What AI said:** scroll to the end of the AI's answer and pick its 3 most important points. Write them in your own short words.
> 3. **Pass / fail:** tick the 3 boxes. All 3 ticked = PASS.
> 4. **My judgment:** for each point: accept, change, or reject, and *why* (point to an OBS, EXP or Done-when line).
> 5. **Files changed:** type `git status` and copy what it lists.
> Tip: you can ask the AI "Summarize your answer in 3 lines", but the judgment line must be yours.

**Name:** ______ · **Role (Day 2):** Product / Evidence / Tech lead · **Tool:** Claude Code / Codex · **Team:** ______

## Entry 1 · /office-hours (Lab 2)
- **Prompt:** (paste the first lines)
- **What AI said (3 lines):**
  1.
  2.
  3.
- **Question that surprised me:**
- **Pass / fail:** specific user ☐ · real pain ☐ · assumption to test ☐ → PASS / FAIL
- **My judgment:** (what I'd change in PRD_BM, and why)
- **Files changed:** (check `git status`: only the design doc?)

## Entry 2 · /plan-______-review (Lab 3)
- **My lens:** CEO / Design / Eng
- **Mode / choices I made:**
- **Top 3 findings:**
  1.
  2.
  3.
- **My judgment:** accept / change / reject for each

## Entry 3 · Build DEC-___ → /review → /qa-only (Lab 5)
- **Change asked:**
- **git diff:** __ files, +__ / −__ lines · anything I didn't ask for?
- **/review:** (auto-fixed / asked, and what I approved)
- **/qa-only:** (which Given/When/Then lines passed)
- **My judgment:**
