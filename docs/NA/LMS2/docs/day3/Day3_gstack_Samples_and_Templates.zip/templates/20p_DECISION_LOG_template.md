# DECISION_LOG.md — Team decisions · BLANK (Lab 4, slide 20)

> Examples: `../samples/20p_DECISION_LOG_sample.md`, `../samples/20p_PRD_BM_v2_sample.md`.
> **Why** must point to evidence (OBS, EXP, review finding #, test). Not "because AI said so".
> Then update `docs/PRD_BM.md`: add the DEC tag to each changed line; write "Done when" as Given / When / Then.
>
> **How to write (team, 20 min · Product lead types, everyone checks)**
> 1. Take every **accept** and **change** row from PLAN_REVIEW.md. Each becomes one DEC block (3–5 in total).
> 2. **Title:** the decision in one line, starting with a verb (Cut…, Add…, Stop…).
> 3. **Why:** point to evidence: OBS-###, EXP-###, review finding #, or a test result.
> 4. **Owner:** one person's name. **Review:** when you will check it again (after Lab 5, tomorrow, before demo).
> 5. Then open `docs/PRD_BM.md`, change only what the DECs say, and add the DEC tag on each changed line.
> 6. Rewrite each "Done when" as Given / When / Then. Test: could two people judge it the same way?

**DEC-001 · ______**
- Why:
- Owner: ______ · Review: ______

**DEC-002 · ______**
- Why:
- Owner: ______ · Review: ______

**DEC-003 · ______**
- Why:
- Owner: ______ · Review: ______

**DEC-004 · ______**
- Why:
- Owner: ______ · Review: ______

---
Given / When / Then helper (copy for each "Done when" line):
- [ ] F_-_ · **Given** ______ · **When** ______ · **Then** ______
