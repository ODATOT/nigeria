# PLAN_REVIEW.md — Team merge of 3 plan reviews · BLANK (Lab 3, slide 18)

> Example: `../samples/18p_PLAN_REVIEW_sample.md`. Each person brings their top 3 findings.
> **Team says:** accept · change (how?) · reject (why?)
>
> **How to write (team, 10 min · Product lead runs the meeting, Tech lead types)**
> 1. Fill the first table: who ran which review, and the main choice they made when AI asked.
> 2. Each person reads out their **top 3 findings** (from their GSTACK_LOG entry 2). Type one row each.
> 3. **Evidence it points to:** an OBS, EXP, Done-when line or score. No evidence? Write "none".
> 4. Decide each row together: **accept** · **change** (say how) · **reject** (say why: A/B/C from COMPARE is a good reason).
> 5. Last 2 lines: where the lenses agreed, and where they disagreed and what you chose.

| Who | Skill | Mode / main choice |
|---|---|---|
| | /plan-ceo-review | |
| | /plan-design-review | |
| | /plan-eng-review | |

| # | Finding | From | Evidence it points to | Team says |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |
| 6 | | | | |
| 7 | | | | |
| 8 | | | | |
| 9 | | | | |

**Where the 3 lenses agreed:**
**Where they disagreed (and what we chose):**
