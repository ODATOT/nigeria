# 32p_PRD_BM_template.md — PRD-lite + BM in 3 lines · BLANK (Team lab 3, slide 32, 25 min)

> Examples: `../samples/16p_PRD_sample.md`, `../samples/16p_BM_sample.md` (ADR: `16p_ADR_sample.md`, optional)
> Save as `docs/PRD_BM.md`. Copy your "PRD" and "FAKE" sentences from the iceberg notes.
> We rebuild the **pattern**, not the service: no name, logo, colours, pictures or text copied.

**Team:** ______  **Service:** ______

## PRD-001 · "______" (your own name)

- **User:** ______ (who, where, which device)
- **Goal (one AARRR stage):** ______
- **Success number (from EXP-001):** ______

| ID | Feature | Based on (OBS / EXP) | Hidden part (one line) |
|---|---|---|---|
| F1 | | | |
| F2 | | | |
| F3 | | | |

**Done when** (we can test each line):
- [ ] F1:
- [ ] F2:
- [ ] F3:
- [ ] Works on a phone screen (360px)

**What we fake:** (sample data instead of ______; we can't have ______)

**Not in this version:** ______

---

## BM in 3 lines

1. **Who pays the original, for what:** ______ *(Based on OBS-___, hypothesis)*
2. **Which of our features helps that money:** F__, because ______
3. **If ours were real, who would pay us:** ______ *(hypothesis)*

---

## ADR-001 (OPTIONAL: only if someone in the team has IT experience)

- **We need:**
- **Options:** (1) ______ · (2) ______
- **Decision:**
- **Why:**
- **What we lose:**
