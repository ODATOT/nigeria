# Helper prompt: let AI format your notes (not invent them)

Paste your rough notes after this prompt, and attach or paste the template.

```text
Here are our rough observation notes and a template.
Put our notes into the template format.
Rules:
- Use ONLY what is in our notes. Do not add any fact, number or feature.
- If a field is missing in our notes, write "[MISSING]" — do not guess.
- Keep "(hypothesis)" in front of every interpretation.
```

Then check every line against your screenshots. Fill each [MISSING] yourself, or delete the card.
