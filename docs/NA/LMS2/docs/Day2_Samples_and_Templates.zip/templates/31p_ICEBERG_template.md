# 31p_ICEBERG_template.md — Hidden parts · BLANK (Team lab 2, slide 31, 10 min)

> Example: `../samples/31p_ICEBERG_NOTES_sample.md`
> Pick 3–5 features from your OBS_LOG.md (Lab 1). For each: what is hidden underneath, and where it goes.
> **Goes to:** PRD (who, why, what to build) · BM (money, costs) · FAKE (data or people we can't have)
> Hidden layers to think about: Experiments · Data · Operations · Context · Constraints · Intent

**Team:** ______  **Service:** ______

| Feature (OBS-###) | Hidden part (hypothesis) | Goes to | Sentence for the document |
|---|---|---|---|
| | | PRD / BM / FAKE | |
| | | PRD / BM / FAKE | |
| | | PRD / BM / FAKE | |
| | | PRD / BM / FAKE | |
| | | PRD / BM / FAKE | |
