# 26p_OBS_template.md — Observation cards + loop · BLANK (Team lab 1, slide 26, 15 min)

> Examples: `../samples/16p_OBS_sample.md` and `../samples/24p_GROWTH_LOOP_EXP_sample.md`
> Save as `research/OBS_LOG.md`. Aim for 10 cards (at least 6). Each card = 5 lines.
> Fact = only what you see (numbers, words on screen). Interpretation always starts with "(hypothesis)".
> Stage = Acquisition · Activation · Retention · Referral · Revenue

**Team:** ______  **Service:** ______

| ID | What we saw | Stage |
|---|---|---|
| OBS-001 | | |
| OBS-002 | | |
| OBS-003 | | |
| OBS-004 | | |
| OBS-005 | | |
| OBS-006 | | |
| OBS-007 | | |
| OBS-008 | | |
| OBS-009 | | |
| OBS-010 | | |

---

## OBS-001 · ______
- **When / where / device:**
- **Fact:**
- **Interpretation:** (hypothesis)
- **Stage:** ______ · **Screenshot:** evidence/OBS-001.png

## OBS-002 · ______
- **When / where / device:**
- **Fact:**
- **Interpretation:** (hypothesis)
- **Stage:** ______ · **Screenshot:** evidence/OBS-002.png

## OBS-003 · ______
- **When / where / device:**
- **Fact:**
- **Interpretation:** (hypothesis)
- **Stage:** ______ · **Screenshot:** evidence/OBS-003.png

## OBS-004 · ______
- **When / where / device:**
- **Fact:**
- **Interpretation:** (hypothesis)
- **Stage:** ______ · **Screenshot:** evidence/OBS-004.png

## OBS-005 · ______
- **When / where / device:**
- **Fact:**
- **Interpretation:** (hypothesis)
- **Stage:** ______ · **Screenshot:** evidence/OBS-005.png

## OBS-006 · ______
- **When / where / device:**
- **Fact:**
- **Interpretation:** (hypothesis)
- **Stage:** ______ · **Screenshot:** evidence/OBS-006.png

## OBS-007 · ______
- **When / where / device:**
- **Fact:**
- **Interpretation:** (hypothesis)
- **Stage:** ______ · **Screenshot:** evidence/OBS-007.png

## OBS-008 · ______
- **When / where / device:**
- **Fact:**
- **Interpretation:** (hypothesis)
- **Stage:** ______ · **Screenshot:** evidence/OBS-008.png

## OBS-009 · ______
- **When / where / device:**
- **Fact:**
- **Interpretation:** (hypothesis)
- **Stage:** ______ · **Screenshot:** evidence/OBS-009.png

## OBS-010 · ______
- **When / where / device:**
- **Fact:**
- **Interpretation:** (hypothesis)
- **Stage:** ______ · **Screenshot:** evidence/OBS-010.png

---

## Growth loop (put an OBS on every arrow)

```text
______________________  (OBS-___)
  → ______________________  (OBS-___)
  → ______________________  (OBS-___)
  → ______________________  (OBS-___)  → back to the start
```

**What would stop it:** ______

## Experiment (your best ICE idea)

**EXP-001:** If ______, then ______ goes up by ___%, because OBS-___ shows ______.

(ICE: Impact __ · Confidence __ · Ease __ → __)
