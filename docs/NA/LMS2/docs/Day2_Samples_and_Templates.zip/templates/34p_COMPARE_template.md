# 34p_COMPARE_template.md — Compare original vs ours · BLANK (Team lab 5, slide 34, 15 min)

> Example: `../samples/16p_CMP_sample.md`
> Save as `build/COMPARE.md`. Same task, same phone. One row per feature (F1–F3) plus 1–2 extra checks.
> **Why different?** has only 3 answers:
> **A** = we didn't write it in our documents · **B** = AI used its usual pattern · **C** = hidden part we can't copy (data, people, money)

**Team:** ______  **Task:** On a phone, ______

| # | Check | Original | Ours | Same? (Yes / Partly / No) | Why different? (A / B / C) |
|---|---|---|---|---|---|
| 1 | F1 | | | | |
| 2 | F2 | | | | |
| 3 | F3 | | | | |
| 4 | | | | | |
| 5 | | | | | |

**Our next fix:** row __ (an "A" is the easiest: add one line to PRD_BM.md and ask AI again).

**One sentence:** With one line, AI built __ of our 3 features. With our documents, it built __. So ______.
