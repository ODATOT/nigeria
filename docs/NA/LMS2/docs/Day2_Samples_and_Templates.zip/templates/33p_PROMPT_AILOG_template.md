# 33p_PROMPT_AILOG_template.md — Prompt + AI log · BLANK (Team lab 4, slide 33, 25 min)

> Examples: `../samples/33p_PROMPT_sample.md`, `../samples/16p_AI_LOG_sample.md`
> Save as `build/AI_LOG.md`.

## Step 1 · Attach the files

ChatGPT / Claude / Gemini: new chat → **+** or **📎** → upload `PRD_BM.md` and `OBS_LOG.md`.
Can't upload? Paste each file between `=== PRD_BM.md ===` and `=== END ===`.
Codex / Antigravity: put the files in `docs/` and write "Read docs/PRD_BM.md and docs/OBS_LOG.md first."

## Step 2 · Prompt (fill the blanks, then copy)

```text
Read the attached files first: PRD_BM.md and OBS_LOG.md.
1. In 5 lines, tell me: the user, the goal, features F1–F3 and the OBS each is based on.
2. Wait for my OK.
3. Then build only F1–F3 as one simple web page (HTML, CSS, JavaScript) with sample data.
Done when: every "Done when" line in PRD_BM.md works on a 360px phone screen.
Don't: copy the original's name, logo, colours, pictures or text. Don't add ______.
```

## Step 3 · AI log (one block each time AI does a real task)

**AI-001 · ______**
- AI's 5-line summary correct? Yes / No: ______
- What AI built:
- We kept:
- We changed:
- We rejected:

**AI-002 · ______**
- Asked:
- Kept / changed / rejected:
