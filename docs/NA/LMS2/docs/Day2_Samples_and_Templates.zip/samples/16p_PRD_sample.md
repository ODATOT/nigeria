# 16p_PRD_sample.md — PRD-lite · YouTube EXAMPLE

> Example for Team lab 3 (slide 32). Blank form: `32p_PRD_BM_template.md`.
> We rebuild the **pattern**, not YouTube: no name, logo, colours, pictures or text copied.

## PRD-001 · "SkillView": keep first-time viewers learning

- **User:** a small-business owner in Lagos who wants to learn Excel on a phone, careful with data.
- **Goal (one AARRR stage):** Activation → the viewer watches a 2nd video without searching.
- **Success number (from EXP-001):** 2nd-video rate +10%.

| ID | Feature | Based on | Hidden part (one line) |
|---|---|---|---|
| F1 | 5-second countdown to the next video, showing its length, with Cancel | OBS-004, EXP-001 | Costly data → show length, allow Cancel |
| F2 | Subscribe button; Home shows "new" on subscribed channels | OBS-006, OBS-007 | No real notifications → "new" label |
| F3 | Share button that opens WhatsApp with the link | OBS-009 | People share by WhatsApp first |

**Done when** (we can test each line):
- [ ] F1: at the end of a video, the countdown shows the next title and length; Cancel stops it
- [ ] F2: Subscribe stays after reloading the page; Home shows "new" for that channel
- [ ] F3: Share opens WhatsApp (or "Copy link" on a laptop)
- [ ] Works on a phone screen (360px)

**What we fake:** we build with HTML, CSS and JavaScript (AI writes it). We fake videos (picture + "End" button), ads (grey box) and notifications ("new" label) with sample data. We can't have personal recommendations.

**Not in this version:** login, upload, comments, real videos, real ads.
