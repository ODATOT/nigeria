# 24p_GROWTH_LOOP_EXP_sample.md — Loop and experiment · YouTube EXAMPLE

> Example for the end of Team lab 1 (slide 26). Blank form: inside `26p_OBS_template.md`.

## Growth loop (an OBS on every arrow)

```text
Viewer watches a video            (OBS-004)
  → YouTube learns what they like  (OBS-007, hypothesis)
  → Better next video and Home     (OBS-004, OBS-007)
  → Viewer watches more and shares (OBS-009)
  → Friends arrive by link         (OBS-002)  → back to the start
```

**What would stop it:** the next videos feel repetitive · mobile data is too expensive.

## Experiment (our best idea from ICE)

**EXP-001:** If the countdown shows the next video's **length** and a **Cancel** button,
then **2nd-video rate** goes up by **10%**, because OBS-004 shows viewers already accept autoplay
and length helps people on costly data decide.

(ICE: Impact 8 · Confidence 6 · Ease 8 → 7.3)
