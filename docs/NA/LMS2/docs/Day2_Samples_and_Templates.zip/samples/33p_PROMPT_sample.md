# 33p_PROMPT_sample.md — Prompt + AI log · YouTube EXAMPLE

> Example for Team lab 4 (slide 33). Blank form: `33p_PROMPT_AILOG_template.md`.

## Before the prompt: attach the files

ChatGPT / Claude / Gemini: new chat → **+** or **📎** → upload `PRD_BM.md` and `OBS_LOG.md`.
Can't upload? Paste the text of each file between `=== PRD_BM.md ===` and `=== END ===`.

## Prompt

```text
Read the attached files first: PRD_BM.md and OBS_LOG.md.
1. In 5 lines, tell me: the user, the goal, features F1–F3 and the OBS each is based on.
2. Wait for my OK.
3. Then build only F1–F3 as one simple web page (HTML, CSS, JavaScript) with sample data.
Done when: every "Done when" line in PRD_BM.md works on a 360px phone screen.
Don't: copy the original's name, logo, colours, pictures or text. Don't add login or extra features.
```

## AI log

- **AI's 5-line summary correct?** Yes: it named F1 (OBS-004), F2 (OBS-006), F3 (OBS-009).
- **What AI built:** one page with 8 sample videos, countdown, Subscribe, Share.
- **We kept:** the countdown with Cancel (F1), Subscribe saved after reload (F2).
- **We changed:** the countdown didn't show the length → we asked AI to add it (F1).
- **We rejected:** a "Sign in to continue" screen → not in our PRD.
