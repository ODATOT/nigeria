# 16p_BM_sample.md — BM in 3 lines · YouTube EXAMPLE

> Example for Team lab 3 (slide 32). Blank form: bottom of `32p_PRD_BM_template.md`.

1. **Who pays the original, for what:** advertisers pay for viewers' attention (ads before videos); some viewers pay for Premium to remove ads. *(Based on OBS-010, hypothesis)*
2. **Which of our features helps that money:** F1, because more videos per visit = more ad places. F3 brings new viewers for free.
3. **If ours were real, who would pay us:** banks or fintechs sponsoring business lessons, and learners paying for a certificate. *(hypothesis)*
