# 16p_ADR_sample.md — Tech decision · YouTube EXAMPLE (OPTIONAL)

> **Optional.** Only if someone in the team has IT experience. Otherwise the "What we fake" line in the PRD is enough.

**ADR-001 · Simple web page with sample data**
- **We need:** F1–F3 working on a phone, built in one morning.
- **Options:** (1) HTML/CSS/JS + sample data · (2) React · (3) real YouTube API
- **Decision:** (1)
- **Why:** fastest, no API keys, no copyright problems, AI builds it reliably.
- **What we lose:** real videos and personal recommendations (expected difference in the compare step).
