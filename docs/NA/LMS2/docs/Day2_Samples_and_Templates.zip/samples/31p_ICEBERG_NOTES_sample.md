# 31p_ICEBERG_NOTES_sample.md — Hidden parts · YouTube EXAMPLE

> Example for Team lab 2 (slide 31). Blank form: `31p_ICEBERG_template.md`.
> For each feature: what is hidden underneath (AI can't see it), and where it goes.
> **Goes to:** PRD (who, why, what to build) · BM (money, costs) · FAKE (data or people we can't have → "What we fake" in PRD)

| Feature | Hidden part (hypothesis) | Goes to | Sentence for the document |
|---|---|---|---|
| Next video starts by itself (OBS-004) | Viewers are on phones with costly data (Context) | PRD | "Countdown shows the next video's length and a Cancel button." |
| Next video starts by itself (OBS-004) | Watch history picks the next video (Data) | FAKE | "Next video = another video on the same topic (sample data)." |
| Subscribe + bell (OBS-006) | A whole notification system and staff (Operations) | FAKE | "No real notifications: a 'new' label on Home instead." |
| Ad + Skip (OBS-010) | Advertisers pay per view (Constraints / money) | BM | "Advertisers pay for views; more videos per visit = more ads." |
| Share to WhatsApp (OBS-009) | People in Nigeria share by WhatsApp first (Context) | PRD | "Share button opens WhatsApp with the video link." |
