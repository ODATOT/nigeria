# 16p_OBS_sample.md — Observation cards · YouTube EXAMPLE

> Example for Team lab 1 (slide 26). Blank form: `26p_OBS_template.md`.
> Each card has only **5 lines**. `[brackets]` = check on your own screen.

| ID | What we saw | Stage |
|---|---|---|
| OBS-001 | Google shows YouTube videos | Acquisition |
| OBS-002 | A WhatsApp link plays without sign-up | Acquisition |
| OBS-003 | Logged-out Home asks you to search | Acquisition |
| OBS-004 | Next video starts by itself | Activation |
| OBS-005 | Comments under the video | Activation |
| OBS-006 | Subscribe button and bell | Retention |
| OBS-007 | Logged-in Home follows my interests | Retention |
| OBS-008 | Next day, Home shows the same topic | Retention |
| OBS-009 | Share to WhatsApp in one tap | Referral |
| OBS-010 | Ad before the video, Skip after a few seconds | Revenue |

---

## OBS-001 · Google shows YouTube videos
- **When / where / device:** 25 Nov 10:02 · google.com, search "excel budget" · Android, Chrome
- **Fact:** The results show a "Videos" block; [3] of the first [4] videos are from YouTube.
- **Interpretation:** (hypothesis) People who never planned to open YouTube arrive from Google for free.
- **Stage:** Acquisition · **Screenshot:** evidence/OBS-001.png

## OBS-002 · A WhatsApp link plays without sign-up
- **When / where / device:** 25 Nov 10:05 · youtube.com link from WhatsApp · Android, logged out
- **Fact:** The video starts at once. No sign-up is asked; "Sign in" is optional at the top.
- **Interpretation:** (hypothesis) New viewers get value before being asked for anything.
- **Stage:** Acquisition · **Screenshot:** evidence/OBS-002.png

## OBS-003 · Logged-out Home asks you to search
- **When / where / device:** 25 Nov 10:07 · youtube.com Home · laptop, private window
- **Fact:** [Write exactly what you see: e.g. "a search bar and the words 'Try searching to get started'"].
- **Interpretation:** (hypothesis) YouTube needs a first search to learn what a stranger likes.
- **Stage:** Acquisition · **Screenshot:** evidence/OBS-003.png

## OBS-004 · Next video starts by itself
- **When / where / device:** 25 Nov 10:12 · watch page, end of video · Android app, logged out
- **Fact:** When the video ended, a [5]-second countdown showed the next video with a "Cancel" button.
- **Interpretation:** (hypothesis) Removing the question "what next?" keeps people watching.
- **Stage:** Activation · **Screenshot:** evidence/OBS-004.png

## OBS-005 · Comments under the video
- **When / where / device:** 25 Nov 10:15 · watch page, below the description · Android app
- **Fact:** The comments show a total of [1,240] and are sorted by "Top comments".
- **Interpretation:** (hypothesis) Seeing other real viewers makes the video feel trustworthy.
- **Stage:** Activation · **Screenshot:** evidence/OBS-005.png

## OBS-006 · Subscribe button and bell
- **When / where / device:** 25 Nov 10:18 · next to the channel name · Android app, logged in
- **Fact:** After tapping "Subscribe", a bell appears with "All / Personalised / None".
- **Interpretation:** (hypothesis) The bell lets YouTube bring the viewer back later.
- **Stage:** Retention · **Screenshot:** evidence/OBS-006.png

## OBS-007 · Logged-in Home follows my interests
- **When / where / device:** 25 Nov 10:20 · Home · Android app, logged in
- **Fact:** [5] of the first [8] videos are about Excel, the topic I watched today.
- **Interpretation:** (hypothesis) Watch history shapes Home, so the next visit is easier.
- **Stage:** Retention · **Screenshot:** evidence/OBS-007.png

## OBS-008 · Next day, Home shows the same topic
- **When / where / device:** 26 Nov [time] · Home · same phone and account
- **Fact:** [Write what you see. If nothing related appears, write that.]
- **Interpretation:** (hypothesis) Yesterday's watching makes today's visit start faster.
- **Stage:** Retention · **Screenshot:** evidence/OBS-008.png

## OBS-009 · Share to WhatsApp in one tap
- **When / where / device:** 25 Nov 10:25 · "Share" under the player · Android app, logged out
- **Fact:** The share panel shows WhatsApp first, then [Facebook, X, Copy link]. Works without signing in.
- **Interpretation:** (hypothesis) Every viewer can bring friends in one tap.
- **Stage:** Referral · **Screenshot:** evidence/OBS-009.png

## OBS-010 · Ad before the video, Skip after a few seconds
- **When / where / device:** 25 Nov 10:28 · before a video starts · Android app, logged out
- **Fact:** A [15]-second ad played; a "Skip" button appeared after [5] seconds.
- **Interpretation:** (hypothesis) Advertisers pay for viewers' attention; Skip keeps viewers from leaving.
- **Stage:** Revenue · **Screenshot:** evidence/OBS-010.png
