# 16p_AI_LOG_sample.md — AI log · YouTube EXAMPLE

> Same as the AI log at the bottom of `33p_PROMPT_sample.md`. Keep one short block each time AI does a real task.

**AI-001 · Build F1–F3**
- AI's summary correct? Yes (F1 OBS-004, F2 OBS-006, F3 OBS-009)
- Kept: countdown with Cancel; Subscribe saved after reload
- Changed: added video length to the countdown (PRD F1)
- Rejected: "Sign in to continue" screen (not in PRD)

**AI-002 · Fix the empty screen**
- Asked: show "No videos" when the list is empty (PRD Done when)
- Kept: yes
