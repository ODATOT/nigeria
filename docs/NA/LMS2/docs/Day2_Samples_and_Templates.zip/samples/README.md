# Day 2–3 · YouTube EXAMPLES (filled in) — blank forms are in ../templates/

| Example (filled) | Blank form | Team lab · slide |
|---|---|---|
| 16p_OBS_sample.md + 24p_GROWTH_LOOP_EXP_sample.md | 26p_OBS_template.md | Lab 1 · slide 26 |
| 31p_ICEBERG_NOTES_sample.md | 31p_ICEBERG_template.md | Lab 2 · slide 31 |
| 16p_PRD_sample.md + 16p_BM_sample.md (+ 16p_ADR_sample.md, optional) | 32p_PRD_BM_template.md | Lab 3 · slide 32 |
| 33p_PROMPT_sample.md + 16p_AI_LOG_sample.md | 33p_PROMPT_AILOG_template.md | Lab 4 · slide 33 |
| 16p_CMP_sample.md | 34p_COMPARE_template.md | Lab 5 · slide 34 |

Follow one feature across the examples: OBS-004 → EXP-001 → PRD F1 → BM line 2 → AI-001 → Compare row 1.
`[brackets]` = check on the live app. Use the format, not the content.
