# 16p_CMP_sample.md — Compare · YouTube EXAMPLE

> Example for Team lab 5 (slide 34). Blank form: `34p_COMPARE_template.md`.
> Same task, same phone. One row per feature. "Why different?" has only 3 answers:
> **A** = we didn't write it in our documents · **B** = AI used its usual pattern · **C** = hidden part we can't copy (data, people, money)

**Task:** On a phone, open a how-to video, watch to the end, continue to a 2nd video, subscribe, share.

| # | Check | Original | Ours | Same? | Why different? |
|---|---|---|---|---|---|
| 1 | F1 next video starts by itself | Yes, [5]-s countdown | Yes, 5-s countdown + length + Cancel | Yes | — |
| 2 | Next video fits my interest | Yes, feels personal | Same topic only | No | C (no watch history) |
| 3 | F2 subscribe → see new videos later | Feed + notification | "new" label only | Partly | C (no notification system) |
| 4 | F3 share to WhatsApp | Yes, [2] taps | Yes, 1 tap | Yes | — |
| 5 | Video length on every card | Yes | No | No | A (not in our PRD) |

**One sentence:** With one line, AI built 0 of our 3 features. With our documents, it built 3. So the quality came from our analysis, not from AI.
