# MARKET_TALK.md — Team talk after /office-hours · BLANK (Lab 1, slide 17)

> Example: `../samples/17p_MARKET_TALK_sample.md`.
>
> **How to write (team, 10 min talk + 1 min to present)**
> 1. Each person reads their GSTACK_LOG entry 1: "My user is now … because AI asked …".
> 2. Fill one column each. **Market** = which group of people, where. **Who pays** = the BM line.
> 3. Talk: why did we end up in different markets? Which questions or OBS pushed each of us?
> 4. You do **not** need to agree. Everyone keeps their own product.
> 5. Write the 3 presentation sentences at the bottom. One person presents in 1 minute.

| | A · ______ | B · ______ | C · ______ |
|---|---|---|---|
| User / market I now aim at | | | |
| What changed it | | | |
| Who pays? (BM) | | | |
| Biggest assumption left | | | |

## What we present (1 minute)
1. Our three products aim at ______.
2. We differ because ______.
3. The assumption we must test first: ______.
