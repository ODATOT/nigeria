# ADR.md — Architecture Decision Record · BLANK (Lab 2 · Plan, slide 20)

> Example: `../samples/20p_ADR_sample.md`. Save as `docs/ADR.md`.
>
> **How to write (solo, 5 min)**
> 1. After your /plan-eng-review, paste: `Write our 1-2 main tech decisions as docs/ADR.md.`
> 2. Check that each decision has the 5 parts: **We need** · **Options** · **Decision** · **Why** · **What we lose**.
> 3. **Why** must point to the POC (one day, phone, no real data), a DEC or the PRD. Not "it's popular".
> 4. **What we lose** is honest: every choice gives something up. If it's empty, ask AI "What do we lose with this choice?"
> 5. Only 1–2 decisions. An ADR is the *big* choices, not every detail.
> 6. Read it once more. Agree → keep. Disagree → ask AI to change it and say why.

## ADR-001 · ______

- **We need:**
- **Options:** (a) ______ · (b) ______ · (c) ______
- **Decision:**
- **Why:**
- **What we lose:**

## ADR-002 · ______

- **We need:**
- **Options:** (a) ______ · (b) ______
- **Decision:**
- **Why:**
- **What we lose:**

**My check:** (agree? what did I change?)
