# REVIEW_QA.md — Build, review, test · BLANK (Lab 4, slide 25)

> Example: `../samples/25p_REVIEW_QA_sample.md`.
>
> **How to write (solo, fill it as you go through Lab 4)**
> 1. **Build:** on a branch (`day3-build`), which DECs you built, and `git diff --stat` numbers. Anything you didn't ask for? Undo + ask again.
> 2. **/review:** one row per [AUTO-FIXED] or [ASK] item. For each [ASK]: **agree → approve**, **disagree → reject, one line why**.
> 3. **/qa-only:** pass / fail for each Given/When/Then line, then the bug list.
> 4. **/qa:** write which bugs you chose to fix and why you skipped the others. Only those get fixed.
> 5. Last line: what is still not working → a new DEC.

**Build:** DEC-___ · `git diff --stat`: __ files, +__ −__ · anything extra?

## /review
| # | Item | Type (AUTO-FIXED / ASK) | I say (approve / reject / keep) | Why |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |

## /qa-only
| Done when | Result |
|---|---|
| | |
| | |
| | |

Bugs:

## /qa
- **I chose:** ______ **Skipped:** ______ (why)
- **Result:**

**Still not working → new DEC:**
