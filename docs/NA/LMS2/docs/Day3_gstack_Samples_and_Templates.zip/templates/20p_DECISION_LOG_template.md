# DECISION_LOG.md — My decisions · BLANK (Lab 2 · Plan, slide 20)

> Examples: `../samples/20p_DECISION_LOG_sample.md`, `../samples/20p_PRD_BM_v2_sample.md`.
>
> **How to write (solo, 5 min)**
> 1. Take every **accept** and **change** row from PLAN_REVIEW.md. Each becomes one DEC block (3–5 in total).
> 2. **Title:** the decision in one line, starting with a verb (Cut…, Add…, Stop…).
> 3. **Why:** point to evidence: OBS-###, EXP-###, review finding #, or a test result. "Because AI said so" is not a reason.
> 4. **Check:** when and how you'll know it worked (Lab 4 test, /qa-only, before demo).
> 5. Then ask AI: `Update docs/PRD_BM.md using only the decisions in docs/DECISION_LOG.md. Add the DEC tag on each changed line. Write every Done-when as Given / When / Then.` Read the result: could two people test each line the same way?
> 6. New problems found later (Lab 4, Bug Hunt) are added here as new DECs.

**DEC-001 · ______**
- Why:
- Check:

**DEC-002 · ______**
- Why:
- Check:

**DEC-003 · ______**
- Why:
- Check:

**DEC-004 · ______**
- Why:
- Check:

**DEC-005 · ______**
- Why:
- Check:

---
Given / When / Then helper (copy for each "Done when" line):
- [ ] F_-_ · **Given** ______ · **When** ______ · **Then** ______
