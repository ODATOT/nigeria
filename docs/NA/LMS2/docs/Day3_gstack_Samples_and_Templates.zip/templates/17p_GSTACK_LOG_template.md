# GSTACK_LOG.md — My gstack log · BLANK (all labs)

> Example: `../samples/17p_GSTACK_LOG_sample.md`. One short entry for each step. Save as `docs/GSTACK_LOG.md`.
>
> **How to write (2–3 min after each step)**
> 1. **Prompt:** copy the one line you pasted.
> 2. **What AI said:** scroll to the end of the answer and pick its 3 most important points. Write them in your own short words.
> 3. **My judgment:** for each point: accept, change, or reject, and *why* (point to an OBS, EXP or Done-when line).
> 4. **Files changed:** type `git status` and copy what it lists.
> Tip: you can ask the AI "Summarize your answer in 3 lines", but the judgment line must be yours.

**Name:** ______ · **Product:** ______ · **Tool:** Claude Code / Codex

## Entry 1 · THINK · /office-hours (Lab 1)
- **Prompt:**
- **What AI said (3 lines):**
  1.
  2.
  3.
- **Did my user / market / BM change?** (yes/no, how, and which question or OBS changed it)
- **My judgment:**
- **Files changed:**

## Entry 2 · PLAN · 3 reviews + ADR (Lab 2)
- **CEO:**
- **Design:**
- **Eng:**
- **ADR:**
- **My judgment:** __ accept · __ change · __ reject → DEC-___ to DEC-___

## Entry 3 · DESIGN · /design-consultation (Lab 3)
- **What AI said (3 lines):**
- **My judgment:**

## Entry 4 · BUILD + REVIEW + TEST (Lab 4)
- **Build:** DEC-___ · __ files, +__ / −__ · undo + ask again?
- **/review:** auto-fixed __ · asked __ → approved ______ · rejected ______ (why)
- **/qa-only:** which Given/When/Then lines passed · bugs found
- **/qa:** which bugs I chose to fix, and the result

## Entry 5 · BUG HUNT (owner of ______, planter: ______)
- **Found by hand:** __ of 3 · **found by gstack:** __ of 3 · **nobody found:**
- **Lesson:**
