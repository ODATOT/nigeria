# TEAM_RETRO.md — Show + team retro · BLANK (Lab 5, slide 30)

> Example: `../samples/30p_TEAM_RETRO_sample.md`.
>
> **How to write (team, 20 min)**
> 1. **Show (2 min each):** the page on a phone, `git log --oneline`, and one decision: "I rejected … because …".
> 2. **Discuss (7 min)** with the 4 questions on slide 30. Each answer points to a log entry, a DEC or the Bug Hunt scoreboard.
> 3. **Write (3 min):** finish the 3 lesson sentences. One person reads them aloud.

| | ______ · product | ______ · product | ______ · product |
|---|---|---|---|
| Commits today (`git log --oneline`) | | | |
| One decision | | | |
| Bug Hunt score (by hand / gstack) | | | |

**Same skill, different results:** (why?)
**Rejected:** (which AI suggestion, and why)
**Claude Code vs Codex:** (if both used)
**Bug Hunt:** (what humans caught that gstack missed, and the other way round)

## Our 3 lessons
1. /office-hours changed ______'s user/market because ______.
2. I rejected ______ because ______.
3. gstack caught ______ before a user did.
