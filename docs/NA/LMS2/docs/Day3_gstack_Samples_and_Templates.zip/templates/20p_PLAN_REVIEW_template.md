# PLAN_REVIEW.md — My 3 plan reviews · BLANK (Lab 2 · Plan, slide 20)

> Example: `../samples/20p_PLAN_REVIEW_sample.md`.
> **I say:** accept · change (how?) · reject (why?)
>
> **How to write (solo, 2 min after each review, then 5 min to decide)**
> 1. After each review, write its **top 3 findings** in your own words (9 rows in total).
> 2. **Evidence it points to:** an OBS, EXP, Done-when line or score. No evidence? Write "none".
> 3. Decide each row: **accept** · **change** (say how) · **reject** (say why). A cause from slide 2 (A not in our docs · B AI's usual pattern · C hidden part) is a good reason to reject.
> 4. Last 2 lines: where the 3 reviews agreed, and where they disagreed and what you chose.
> 5. Every accept / change becomes a DEC in DECISION_LOG.md.

| Review | Main choice I made |
|---|---|
| /plan-ceo-review | |
| /plan-design-review | |
| /plan-eng-review (+ ADR.md) | |

| # | Finding | From | Evidence it points to | I say |
|---|---|---|---|---|
| 1 | | CEO | | |
| 2 | | CEO | | |
| 3 | | CEO | | |
| 4 | | Design | | |
| 5 | | Design | | |
| 6 | | Design | | |
| 7 | | Eng | | |
| 8 | | Eng | | |
| 9 | | Eng | | |

**Where the 3 reviews agreed:**
**Where they disagreed (and what I chose):**
