# DESIGN.md — Design system · BLANK (Lab 3 · Design, slide 22)

> Example: `../samples/22p_DESIGN_sample.md`. Save as `docs/DESIGN.md`.
>
> **How to write (solo, 15 min with AI)**
> 1. New session. Paste: `/design-consultation Make a DESIGN.md for the POC in docs/PRD_BM.md. Phone first.`
> 2. Answer its questions in one line each. Think of **your user** (OBS): what phone, what place, what feeling?
> 3. If it asks for an API key or AI mockups: `Skip the AI mockups, the HTML preview is fine.` (AI mockups need a separate OpenAI/Gemini API key, not your Claude or Codex subscription.)
> 4. Check the 4 parts: **Feel** · **Colours + font** · **Sizes** · **Screens with their states** (normal, loading, empty, error).
> 5. States missing? Type `Add the states for each screen.` Then commit.

## Feel
(Who uses it, where, on what phone? What should it feel like?)

## Colours + font
- Action:
- Text:
- Background:
- Font:

## Sizes
- Screen width:
- Buttons:
- Long text:

## Screens and states

| Screen | Normal | Loading | Empty | Error / offline |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

## Not in this design
