# BUGHUNT.md — Bug Hunt · BLANK (slide 28)

> Example: `../samples/28p_BUGHUNT_sample.md`.
> Owner: ______ (product: ______) · Planter: ______ · Branch: `bughunt`
>
> **How to write (team of 3, 30 min · everyone is a planter once and an owner once)**
> Rotate: A plants in B's product, B in C's, C in A's, all at the same time.
> 1. **Plant (5 min, planter at the owner's laptop, owner looks away):** paste the Bug Hunt prompt from slide 28. Check each bug on screen, copy AI's list **on paper**, then **delete the chat**.
> 2. **Hunt (8 min, owner):** use your app like a user: phone size, every button, long text, fast taps. No `git diff`, `git log` or reading code. Each bug: **what I did → what went wrong**.
> 3. **gstack (8 min, owner):** `/review Review this branch against my local main branch (there is no GitHub remote).` then `/qa-only Serve build/ on a local server and test it at phone size.`
> 4. **Reveal (5 min):** the planter reads the paper. Tick who found each bug. Score: +1 per bug found by hand · +1 per bug gstack found · +2 to the planter for each bug nobody found.
> 5. **Back (4 min):** `Switch back to the main branch.` All planted bugs are gone. A real bug you found that is also on main → write it as a new DEC.
> 6. Last 2 lines: what you were better at, what gstack was better at.

## Owner's notes (before the reveal)
| # | What I did | What went wrong |
|---|---|---|
| h1 | | |
| h2 | | |
| h3 | | |

## gstack's findings
- **/review:**
- **/qa-only:**

## Scoreboard (after the reveal)
| # | Planted bug (from the planter's paper) | Owner by hand | /review | /qa-only |
|---|---|---|---|---|
| 1 | | ☐ | ☐ | ☐ |
| 2 | | ☐ | ☐ | ☐ |
| 3 | | ☐ | ☐ | ☐ |

**Score:** by hand __ · gstack __ · planter +__
**Back on main:** ☐
**I was better at:**
**gstack was better at:**
