# 20p_DECISION_LOG_sample.md — My decisions · YouTube "SkillView" EXAMPLE

> Example for Lab 2 · Plan (slide 20), added to in Lab 4. Blank form: `../templates/20p_DECISION_LOG_template.md`.
>
> **How to write (solo, 5 min)**
> 1. Take every **accept** and **change** row from PLAN_REVIEW.md. Each becomes one DEC block (3–5 in total).
> 2. **Title:** the decision in one line, starting with a verb (Cut…, Add…, Stop…).
> 3. **Why:** point to evidence: OBS-###, EXP-###, review finding #, or a test result. "Because AI said so" is not a reason.
> 4. **Check:** when and how you'll know it worked (Lab 4 test, /qa-only, before demo).
> 5. Then ask AI: `Update docs/PRD_BM.md using only the decisions in docs/DECISION_LOG.md. Add the DEC tag on each changed line. Write every Done-when as Given / When / Then.` Read the result: could two people test each line the same way?
> 6. New problems found later (Lab 4, Bug Hunt) are added here as new DECs.

**DEC-001 · Cut F2 (subscribe) from this version**
- Why: CEO review (finding 1) + only one OBS (OBS-006); F1 is the narrowest test of EXP-001
- Check: after the Lab 4 test

**DEC-002 · Add a "no next video" screen to F1**
- Why: Design review rated states 4/10 (finding 4); a real viewer reaches the end of the list
- Check: /qa-only, line F1-3

**DEC-003 · Cancel stops the timer, and the timer stops when the page is hidden**
- Why: Eng review (finding 7); F1 Done when
- Check: /review + /qa-only, lines F1-2 and F1-4

**DEC-004 · No watch history or login in the POC**
- Why: cause C on slide 2 (hidden part: no real data) and B (AI's usual pattern); "What we fake" in PRD_BM
- Check: before the investor demo

*Added in Lab 4:*

**DEC-005 · Timer keeps running when I switch apps (F1-4 fails after /qa)**
- Why: /qa-only report, F1-4 ✗; /qa could not fix it in one try
- Check: tomorrow morning, then /qa-only again
