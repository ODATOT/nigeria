# 20p_PLAN_REVIEW_sample.md — My 3 plan reviews · YouTube "SkillView" EXAMPLE

> Example for Lab 2 · Plan (slide 20). Blank form: `../templates/20p_PLAN_REVIEW_template.md`.
> Ada ran all three reviews on her own `docs/PRD_BM.md`, one after another.
> **I say:** accept · change (how?) · reject (why?)
>
> **How to write (solo, 2 min after each review, then 5 min to decide)**
> 1. After each review, write its **top 3 findings** in your own words (9 rows in total).
> 2. **Evidence it points to:** an OBS, EXP, Done-when line or score. No evidence? Write "none".
> 3. Decide each row: **accept** · **change** (say how) · **reject** (say why). A cause from slide 2 (A not in our docs · B AI's usual pattern · C hidden part) is a good reason to reject.
> 4. Last 2 lines: where the 3 reviews agreed, and where they disagreed and what you chose.
> 5. Every accept / change becomes a DEC in DECISION_LOG.md.

| Review | Main choice I made |
|---|---|
| /plan-ceo-review | Hold scope (one-day POC) |
| /plan-design-review | Fix gaps only |
| /plan-eng-review (+ ADR.md) | Plain HTML/JS, sample data |

| # | Finding | From | Evidence it points to | I say |
|---|---|---|---|---|
| 1 | Cut F2 (subscribe) from this version | CEO | Only OBS-006; F1 tests EXP-001 directly | accept |
| 2 | Success number = 2nd-video rate only | CEO | EXP-001 | accept |
| 3 | Add login so subscribe syncs | CEO | none | reject: not in PRD, cause B on slide 2 (AI's usual pattern) |
| 4 | Add "no next video" screen | Design | States 4/10 | accept |
| 5 | Cancel button 44px, easy for a thumb | Design | 360px phone (Done when) | accept |
| 6 | Long titles: cut at 2 lines | Design | 360px phone | change: 2 lines + "…" |
| 7 | Cancel must stop the timer; stop it when the page is hidden | Eng | F1 Done when | accept |
| 8 | 5 test cases for the countdown | Eng | F1 | accept (become Given/When/Then) |
| 9 | Save watch history to recommend better | Eng | OBS-007 | reject: cause C on slide 2, hidden part (no real data in a POC) |

**Where the 3 reviews agreed:** F1 is the core; keep it small.
**Where they disagreed:** CEO wanted F2 cut, Eng planned it in detail → I chose CEO (DEC-001).
