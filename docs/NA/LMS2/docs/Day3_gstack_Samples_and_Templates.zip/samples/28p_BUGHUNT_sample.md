# 28p_BUGHUNT_sample.md — Bug Hunt · YouTube "SkillView" EXAMPLE

> Example for the Bug Hunt (slide 28). Blank form: `../templates/28p_BUGHUNT_template.md`.
> Owner: Ada (SkillView) · Planter: Tunde (Ada plants in Chidi's product at the same time) · Branch: `bughunt`
> The AI quotes below are illustrations. Your AI's words will be different. That's expected.
>
> **How to write (team of 3, 30 min · everyone is a planter once and an owner once)**
> Rotate: A plants in B's product, B in C's, C in A's, all at the same time.
> 1. **Plant (5 min, planter at the owner's laptop, owner looks away):** paste the Bug Hunt prompt from slide 28. Check each bug on screen, copy AI's list **on paper**, then **delete the chat**.
> 2. **Hunt (8 min, owner):** use your app like a user: phone size, every button, long text, fast taps. No `git diff`, `git log` or reading code. Each bug: **what I did → what went wrong**.
> 3. **gstack (8 min, owner):** `/review Review this branch against my local main branch (there is no GitHub remote).` then `/qa-only Serve build/ on a local server and test it at phone size.`
> 4. **Reveal (5 min):** the planter reads the paper. Tick who found each bug. Score: +1 per bug found by hand · +1 per bug gstack found · +2 to the planter for each bug nobody found.
> 5. **Back (4 min):** `Switch back to the main branch.` All planted bugs are gone. A real bug you found that is also on main → write it as a new DEC.
> 6. Last 2 lines: what you were better at, what gstack was better at.

## Planter's prompt (Tunde, on Ada's laptop)
```
We are playing a training game called Bug Hunt.
1. Create a git branch called bughunt and switch to it.
2. In this project's app, add 3 small, realistic bugs a user could notice. For example: a button that only works the first time, a wrong number or label, a layout that breaks with long text or on a phone.
3. No comments or hints in the code. Don't change the docs.
4. Commit with the message "small update".
5. Show me a numbered list: what you changed, in which file, and how a user can see each bug.
```

## Owner's notes (before the reveal)
| # | What I did | What went wrong |
|---|---|---|
| h1 | Opened the last video and pressed End | blank screen, no "No more videos" |
| h2 | Tapped Share twice fast | WhatsApp opened twice (not planted! it came back) |

## gstack's findings
- **/review:** video length shown in seconds (`120`) instead of minutes (`2:00`) · `indexOf` returns −1 on the last video, no check
- **/qa-only:** F1-3 fails (last video: blank screen) · F1-1: length shows "120"

## Scoreboard (after the reveal)
| # | Planted bug (from Tunde's paper) | Owner by hand | /review | /qa-only |
|---|---|---|---|---|
| 1 | Last video → blank screen | ☑ | ☑ | ☑ |
| 2 | Video length in seconds, not minutes | ☐ | ☑ | ☑ |
| 3 | Cancel ignored in the last second (`>` instead of `>=`) | ☐ | ☐ | ☐ |

**Score:** Ada by hand 1 · gstack 2 · Tunde +2 (bug 3: nobody found it)
**Back on main:** ✓ planted bugs gone. h2 (double Share) is also on main → DEC-006.
**I was better at:** fast taps like a real user (h2 wasn't even planted).
**gstack was better at:** reading code: the seconds/minutes bug. Nobody tests the last second → new Given/When/Then line.
