# 25p_REVIEW_QA_sample.md — Build, review, test · YouTube "SkillView" EXAMPLE

> Example for Lab 4 · Build + Review + Test (slide 25). Blank form: `../templates/25p_REVIEW_QA_template.md`.
> Ada built her accepted decisions (DEC-001 to DEC-003), then let gstack check them. She approved only what she agreed with.
>
> **How to write (solo, fill it as you go through Lab 4)**
> 1. **Build:** on a branch (`day3-build`), which DECs you built, and `git diff --stat` numbers. Anything you didn't ask for? Undo + ask again.
> 2. **/review:** one row per [AUTO-FIXED] or [ASK] item. For each [ASK]: **agree → approve**, **disagree → reject, one line why**.
> 3. **/qa-only:** pass / fail for each Given/When/Then line, then the bug list.
> 4. **/qa:** write which bugs you chose to fix and why you skipped the others. Only those get fixed.
> 5. Last line: what is still not working → a new DEC.

**Build:** on branch `day3-build` · DEC-001, DEC-002, DEC-003 · `git diff --stat`: 2 files, +38 −4 · nothing extra.

## /review
| # | Item | Type | I say | Why |
|---|---|---|---|---|
| 1 | Timer not cleared when the screen ends | AUTO-FIXED | keep | matches DEC-003 |
| 2 | Cancel button not reachable by keyboard | ASK | approve | small fix, helps everyone |
| 3 | Add analytics to count 2nd-video views | ASK | reject | not in PRD; we fake data in this POC (DEC-004) |

## /qa-only
| Done when | Result |
|---|---|
| F1-1 countdown from 5, title + length | ✓ |
| F1-2 Cancel stops it, "Watch next" appears | ✓ |
| F1-3 last video → "No more videos" | ✓ |
| F1-4 switch apps → countdown stops | ✗ |

Bugs: (1) long title overflows on video 7 at 360px · (2) Share opens WhatsApp twice on fast taps · (3) "Back to list" button is grey, hard to see

## /qa
- **I chose:** bugs 1 and 2 (users will hit them). **Skipped:** 3 (matches DESIGN.md colours; I'll check with users first).
- **Prompt:** `/qa Fix only bugs 1 and 2 from the last QA report, then test again.`
- **Result:** 1 and 2 fixed and re-tested ✓ · F1-4 still ✗

**Still not working → new DEC:** DEC-005 (timer when switching apps).
**Commit + merge:** "Fix title overflow and double Share (QA bugs 1, 2). Before: … Now: … Not yet: F1-4." → merged `day3-build` into main.
