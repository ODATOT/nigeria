# 20p_PRD_BM_v2_sample.md — PRD_BM after gstack · YouTube "SkillView" EXAMPLE

> Example for Lab 2 · Plan (slide 20). Start from YOUR Day 2 `docs/PRD_BM.md` and change only what DECISION_LOG says.
> Changed lines carry a DEC tag. "Done when" is now Given / When / Then.

## PRD-001 v2 · "SkillView": keep first-time viewers learning

- **User:** a shop owner in Lagos who learns Excel on a phone in the evening, careful with mobile data *(narrowed after /office-hours)*
- **Goal:** Activation → the viewer watches a 2nd video without searching
- **Success number:** 2nd-video rate +10% (EXP-001)

| ID | Feature | Based on | Hidden part | DEC |
|---|---|---|---|---|
| F1 | 5-second countdown to the next video, with its length and a Cancel button (44px) | OBS-004, EXP-001 | Costly data → show length, allow Cancel | DEC-002, DEC-003 |
| ~~F2~~ | ~~Subscribe + "new" label~~ → next version | OBS-006 | | DEC-001 |
| F3 | Share button opens WhatsApp with the link | OBS-009 | People share by WhatsApp first | — |

**Done when (Given / When / Then):**
- [ ] F1-1 · **Given** a video ends and there is a next video · **When** I wait · **Then** a countdown from 5 shows the next title and its length, and the next video opens at 0
- [ ] F1-2 · **Given** the countdown is running · **When** I tap Cancel · **Then** the countdown stops and a "Watch next" button appears (DEC-003)
- [ ] F1-3 · **Given** it is the last video · **When** it ends · **Then** "No more videos in this topic" and a "Back to list" button appear (DEC-002)
- [ ] F1-4 · **Given** the countdown is running · **When** I switch to another app · **Then** the countdown stops (DEC-003)
- [ ] F3-1 · **Given** a phone with WhatsApp · **When** I tap Share · **Then** WhatsApp opens with the video link
- [ ] All screens fit 360px wide; titles cut at 2 lines with "…"

**What we fake:** sample videos (picture + "End" button), next video = same topic; no history, no login (DEC-004).
**Not in this version:** F2 subscribe (DEC-001), comments, upload, real ads.

## BM in 3 lines (unchanged)
1. Advertisers pay for views; some viewers pay for Premium *(OBS-010, hypothesis)*
2. F1 → more videos per visit → more ad places
3. If real: a bank or fintech sponsors business lessons; learners pay for a certificate *(hypothesis)*
