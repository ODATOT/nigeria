# 17p_GSTACK_LOG_sample.md — My gstack log · YouTube "SkillView" EXAMPLE

> Example for every lab (slides 17, 20, 22, 25, 28). Blank form: `../templates/17p_GSTACK_LOG_template.md`.
> One file per person, in your own project: `docs/GSTACK_LOG.md`. One short entry for each step.
> The AI quotes below are illustrations. Your AI's words will be different. That's expected.
>
> **How to write (2–3 min after each step)**
> 1. **Prompt:** copy the one line you pasted.
> 2. **What AI said:** scroll to the end of the answer and pick its 3 most important points. Write them in your own short words.
> 3. **My judgment:** for each point: accept, change, or reject, and *why* (point to an OBS, EXP or Done-when line).
> 4. **Files changed:** type `git status` and copy what it lists.
> Tip: you can ask the AI "Summarize your answer in 3 lines", but the judgment line must be yours.

**Name:** Ada · **Product:** SkillView · **Tool:** Claude Code desktop

---

## Entry 1 · THINK · /office-hours (Lab 1)
- **Prompt:** `/office-hours Read docs/PRD_BM.md and research/OBS_LOG.md. Help me sharpen this idea.`
- **What AI said (3 lines):**
  1. "Costly data" is an assumption: no OBS shows a viewer stopping because of data.
  2. Narrowest first version = F1 only (countdown with length + Cancel).
  3. User is too wide: "small-business owner" → "shop owner who learns Excel on a phone in the evening".
- **Did my user / market / BM change?** Yes: from all small-business owners to shop owners learning Excel. BM stays ads + a bank sponsor, but now aimed at SME banking.
- **My judgment:** accept the narrower user; keep F3 (share) because OBS-009 is strong evidence.
- **Files changed:** only the design doc gstack wrote: `docs/designs/skillview-countdown.md`.

## Entry 2 · PLAN · 3 reviews + ADR (Lab 2)
- **CEO (hold scope):** cut F2 subscribe · success number = 2nd-video rate only · no login
- **Design (fix gaps):** states 4/10, no "no next video" screen · long titles break at 360px · Cancel too small (44px)
- **Eng:** Cancel must stop the timer · timer must stop when the page is hidden · 5 test cases
- **ADR:** plain HTML + JS; sample data in `videos.json`
- **My judgment:** 7 accept, 1 change (titles: 2 lines + "…"), 1 reject (login: not in PRD). → DEC-001 to DEC-004.

## Entry 3 · DESIGN · /design-consultation (Lab 3)
- **What AI said (3 lines):** calm green + grey, system font 16px · 3 screens (Watch, Countdown, No more videos) · every button at least 44px
- **Asked about AI mockups:** I said "Skip the AI mockups, the HTML preview is fine." → preview page opened in the browser.
- **My judgment:** accept; I asked "Add the states for each screen" because "offline" was missing.

## Entry 4 · BUILD + REVIEW + TEST (Lab 4)
- **Build:** DEC-001 to DEC-003 · 2 files, +38 / −4 · first try started the countdown at 10 → undo, asked again with "must start at 5 (F1-1)".
- **/review:** 1 auto-fixed, 2 asked → approved 1 (keyboard focus), rejected 1 (add analytics: not in PRD).
- **/qa-only:** F1-1 ✓ F1-2 ✓ F1-3 ✓ F1-4 ✗ · bugs: (1) title overflow on video 7, (2) Share opens twice on fast taps.
- **/qa:** "Fix only bugs 1 and 2" → both fixed, F1-4 still fails → DEC-005 for tomorrow.

## Entry 5 · BUG HUNT (owner of SkillView, planter: Tunde)
- **Found by hand:** 2 of 3 · **found by gstack:** 2 of 3 · **nobody found:** "Cancel ignored in the last second".
- **Lesson:** I never test the last second. Added a Given/When/Then line for it.
