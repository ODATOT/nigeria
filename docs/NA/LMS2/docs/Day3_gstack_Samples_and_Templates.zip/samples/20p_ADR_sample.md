# 20p_ADR_sample.md — Architecture Decision Record · YouTube "SkillView" EXAMPLE

> Example for Lab 2 · Plan (slide 20). Blank form: `../templates/20p_ADR_template.md`.
> ADR = "Architecture Decision Record": the 1–2 big tech choices, written so you and AI build the same way every time.
> Written by AI after /plan-eng-review, checked by Ada.
> The AI quotes below are illustrations. Your AI's words will be different. That's expected.
>
> **How to write (solo, 5 min)**
> 1. After your /plan-eng-review, paste: `Write our 1-2 main tech decisions as docs/ADR.md.`
> 2. Check that each decision has the 5 parts: **We need** · **Options** · **Decision** · **Why** · **What we lose**.
> 3. **Why** must point to the POC (one day, phone, no real data), a DEC or the PRD. Not "it's popular".
> 4. **What we lose** is honest: every choice gives something up. If it's empty, ask AI "What do we lose with this choice?"
> 5. Only 1–2 decisions. An ADR is the *big* choices, not every detail.
> 6. Read it once more. Agree → keep. Disagree → ask AI to change it and say why.

## ADR-001 · How we build the POC

- **We need:** a one-day POC that runs on a cheap phone and can be shown to an investor.
- **Options:** (a) plain HTML + JavaScript, one page · (b) React app with a build step · (c) no-code tool
- **Decision:** (a) plain HTML + JavaScript in `build/`, no framework, no build step.
- **Why:** one day only; opens by double-click; everyone on the team can read the code; /qa-only can test it in a browser.
- **What we lose:** harder to grow into a big app later; we will rewrite it if the POC works.

## ADR-002 · Where the videos and data come from

- **We need:** videos and a "next video" for F1 without a server.
- **Options:** (a) real YouTube API · (b) sample data in a file
- **Decision:** (b) `build/videos.json` with 8 sample videos (title, length, topic). Each "video" is a picture + an "End" button.
- **Why:** "What we fake" in PRD_BM; no API key, no internet needed in class (DEC-004).
- **What we lose:** no real watch time; the success number (EXP-001) can only be measured in a later real test.

**My check:** agreed. I asked to add "titles can be 90 characters long" to the sample data, so the long-title case is tested.
