# 17p_MARKET_TALK_sample.md — Team talk after /office-hours · EXAMPLE

> Example for Lab 1 · Think, team talk (slide 17). Blank form: `../templates/17p_MARKET_TALK_template.md`.
> Three teammates started from the same Day 2 PRD_BM (YouTube learning). After /office-hours, they aim at different markets.
>
> **How to write (team, 10 min talk + 1 min to present)**
> 1. Each person reads their GSTACK_LOG entry 1: "My user is now … because AI asked …".
> 2. Fill one column each. **Market** = which group of people, where. **Who pays** = the BM line.
> 3. Talk: why did we end up in different markets? Which questions or OBS pushed each of us?
> 4. You do **not** need to agree. Everyone keeps their own product.
> 5. Write the 3 presentation sentences at the bottom. One person presents in 1 minute.

| | A · Ada | B · Tunde | C · Chidi |
|---|---|---|---|
| User / market I now aim at | shop owners in Lagos learning Excel on a phone, evenings | secondary-school students preparing for WAEC exams | trainers at small companies who teach new staff |
| What changed it | AI asked "who exactly?"; OBS-004 (viewers on phones at night) | AI asked "who has the pain most often?"; OBS-002 (students re-watch) | AI asked "who would pay today?"; OBS-010 (Premium) |
| Who pays? (BM) | ads + a bank sponsors business lessons | a mobile network sells a cheap "learning data bundle" | the company pays per staff member |
| Biggest assumption left | viewers stop because of data cost | students will watch a 2nd video without a teacher | trainers will share links instead of slides |

## What we present (1 minute)
1. Our three products aim at **shop owners, exam students and company trainers**.
2. We differ because **AI pushed each of us to a narrower user, and each of us chose different OBS evidence**.
3. The assumption we must test first: **does the countdown really make people watch a 2nd video?** (all three need it)
