# 30p_TEAM_RETRO_sample.md — Show + team retro · EXAMPLE

> Example for Lab 5 · Show + retro (slide 30). Blank form: `../templates/30p_TEAM_RETRO_template.md`.
>
> **How to write (team, 20 min)**
> 1. **Show (2 min each):** the page on a phone, `git log --oneline`, and one decision: "I rejected … because …".
> 2. **Discuss (7 min)** with the 4 questions on slide 30. Each answer points to a log entry, a DEC or the Bug Hunt scoreboard.
> 3. **Write (3 min):** finish the 3 lesson sentences. One person reads them aloud.

| | Ada · SkillView (shop owners) | Tunde · exam students | Chidi · company trainers |
|---|---|---|---|
| Commits today (`git log --oneline`) | 6 | 5 | 7 |
| One decision | rejected analytics: not in PRD | rejected login: AI's usual pattern | cut offline mode: hidden part, no time |
| Bug Hunt score (by hand / gstack) | 1 / 2 | 2 / 2 | 1 / 3 |

**Same skill, different results:** /office-hours sent us to 3 different markets because each of us answered with different OBS.
**Rejected:** login (Tunde) and analytics (Ada): not in PRD_BM, no OBS asked for them.
**Claude Code vs Codex:** Claude Code asked multiple-choice questions; Codex asked in plain chat. Codex's first build added a "Sign in" link we didn't ask for.
**Bug Hunt:** humans found fast-tap bugs gstack missed; gstack found code bugs (`>` vs `>=`, seconds/minutes) humans missed.

## Our 3 lessons
1. /office-hours changed Tunde's user to exam students because it asked "who has the pain most often?" (OBS-002).
2. I rejected analytics because it was not in PRD_BM and we fake data in the POC (DEC-004).
3. gstack caught the "no next video" screen and the running timer **before** a user did (DEC-002, DEC-003).
