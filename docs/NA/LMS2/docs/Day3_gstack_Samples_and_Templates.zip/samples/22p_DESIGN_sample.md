# 22p_DESIGN_sample.md — Design system · YouTube "SkillView" EXAMPLE

> Example for Lab 3 · Design (slide 22). Blank form: `../templates/22p_DESIGN_template.md`.
> Made by /design-consultation (no API key, so an HTML preview instead of AI mockups). Ada added the "offline" state.
> The AI quotes below are illustrations. Your AI's words will be different. That's expected.
>
> **How to write (solo, 15 min with AI)**
> 1. New session. Paste: `/design-consultation Make a DESIGN.md for the POC in docs/PRD_BM.md. Phone first.`
> 2. Answer its questions in one line each. Think of **your user** (OBS): what phone, what place, what feeling?
> 3. If it asks for an API key or AI mockups: `Skip the AI mockups, the HTML preview is fine.` (AI mockups need a separate OpenAI/Gemini API key, not your Claude or Codex subscription.)
> 4. Check the 4 parts: **Feel** · **Colours + font** · **Sizes** · **Screens with their states** (normal, loading, empty, error).
> 5. States missing? Type `Add the states for each screen.` Then commit.

## Feel
Calm and simple. A shop owner learning in the evening on a cheap phone, maybe in a noisy place. Big text, few buttons, nothing that blinks.

## Colours + font
- Action: green `#1f7a52` (Cancel, Watch next, Share)
- Text: dark grey `#24302b` · second text: grey `#5b6b63`
- Background: white `#ffffff` · cards: light grey `#f3f5f4`
- Font: the phone's system font, 16px minimum, titles 20px bold

## Sizes
- Screen width: designed for **360px** first
- Every button: at least **44px** high (thumb size)
- Video titles: at most **2 lines**, then "…"

## Screens and states

| Screen | Normal | Loading | Empty | Error / offline |
|---|---|---|---|---|
| Watch | video picture, title, "End" button | grey box | — | "No internet. Try again" button |
| Countdown (F1) | "Next in 5…", next title + length, big Cancel | — | — | — |
| After Cancel | "Watch next" button + "Back to list" | — | — | — |
| No more videos (DEC-002) | "No more videos in this topic" + "Back to list" | — | list is empty | — |
| Share (F3) | WhatsApp opens with the link | — | — | "WhatsApp not found: copy link" |

## Not in this design
Dark mode, animations, logo, login screen (DEC-004).
