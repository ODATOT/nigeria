# Day 3 · gstack sprint labs · EXAMPLES (samples/) and BLANK FORMS (templates/)

- `samples/…_sample.md` = a filled example (YouTube "SkillView", continuing Day 2). Read it, don't copy it.
- `templates/…_template.md` = the blank form you fill. Save it in your project's `docs/` folder without the number and `_template` (e.g. `docs/ADR.md`).
- The number at the start (17p, 20p…) is the slide where you use it. Each file starts with a **How to write** box.
- Everyone works **alone on their own project**. Team files: MARKET_TALK, BUGHUNT, TEAM_RETRO.
- AI quotes in the examples are illustrations: your AI's answers will be different.

| Step · lab · slide | Example | Blank form | Who |
|---|---|---|---|
| Save point + THINK · Lab 1 · slide 17 | 17p_GSTACK_LOG (entry 1) · 17p_MARKET_TALK | 17p_GSTACK_LOG · 17p_MARKET_TALK | each person → team talk |
| PLAN · Lab 2 · slide 20 | 17p_GSTACK_LOG (entry 2) · 20p_PLAN_REVIEW · 20p_DECISION_LOG · 20p_PRD_BM_v2 · 20p_ADR | 20p_PLAN_REVIEW · 20p_DECISION_LOG · 20p_ADR | each person |
| DESIGN · Lab 3 · slide 22 | 17p_GSTACK_LOG (entry 3) · 22p_DESIGN | 22p_DESIGN | each person |
| BUILD + REVIEW + TEST · Lab 4 · slide 25 | 17p_GSTACK_LOG (entry 4) · 25p_REVIEW_QA | 25p_REVIEW_QA | each person |
| SHIP · slide 26 | — (explained only) | — | — |
| ★ Bug Hunt · slide 28 | 17p_GSTACK_LOG (entry 5) · 28p_BUGHUNT | 28p_BUGHUNT | team of 3, rotate |
| Show + retro · Lab 5 · slide 30 | 30p_TEAM_RETRO | 30p_TEAM_RETRO | team |
