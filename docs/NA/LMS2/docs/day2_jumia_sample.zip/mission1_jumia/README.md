# Day 2 sample (Jumia): read me first

**Morning, Mission 01 (research/)**
1. `research/SCOPE.md`: one service, one user, one task
2. `research/BENCHMARK_LOG.md`: 10 observation cards (OBS)
3. `research/GROWTH_LOOP.md`: AARRR map, growth loop, stop conditions
4. `research/EXPERIMENTS.md`: 5 experiment hypotheses (EXP), ranked with ICE

**Afternoon, iceberg → prompt → rebuild → compare (build/)**
5. `build/ICEBERG_NOTES.md`: hidden layers behind 3 features (Hands-on 06)
6. `build/PROMPT.md`: BEFORE and AFTER prompts + trust count (Hands-on 07)
7. `build/AI_LOG.md`: AI-### work log (accepted / changed / rejected)
8. `build/GAP.md`: design vs AI table + retro (Step 04)

Screenshots go in `evidence/` folders, named with the ID (OBS-003…, BEFORE-01, AFTER-01).

Each file starts with **"How to write this file"**. Delete those blocks in your own files.
This is a **teaching sample**: text in `[brackets]` must be checked on the live site. Don't copy it; use your own observations.
