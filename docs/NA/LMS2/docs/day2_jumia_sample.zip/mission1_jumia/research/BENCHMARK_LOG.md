# BENCHMARK_LOG.md — Observation notes (OBS)

> **How to write this file**
> 1. **One card = one fact.** If a fact needs the word "and", it's probably two cards.
> 2. **Observed fact** = what anyone can check on the screen right now. Use numbers and exact words ("3 of the first 10 cards", "the button says 'Add to cart'").
> 3. **My interpretation** = why I think it is there. Always a hypothesis. Use the pattern:
>    *This [thing] makes the user [do/feel something], which gives the service [growth result].*
> 4. **Test:** could a classmate disagree? → interpretation. Could anyone check it on screen? → fact.
> 5. Anything about algorithms, money or company policy = hypothesis, unless the company says it officially.
> 6. **AARRR stage:** Acquisition (arrive) · Activation (first value) · Retention (come back) · Referral (bring others) · Revenue (pay).
> 7. **Evidence file:** save a screenshot with the same ID: `evidence/OBS-003-official-store-badge.png`.
> 8. **Uncertainty:** what you are not sure about and how you could check it. Honest, not weak.
> 9. Number cards in the order you saw them: OBS-001, OBS-002…  Minimum 10.
>
> ⚠️ Teaching sample written to show the format. `[brackets]` = check on the live screen and fill in. Don't copy these cards: use your own observations.

## Summary

| ID | Card | Session | Stage |
|---|---|---|---|
| OBS-001 | Home page promise in 5 seconds | First visit | Acquisition |
| OBS-002 | Sign-up discount pop-up | First visit | Acquisition |
| OBS-003 | Official Store badge and rating count on cards | Typical task | Activation |
| OBS-004 | Filters for price, brand and Official Store | Typical task | Activation |
| OBS-005 | Verified-purchase reviews on the detail page | Typical task | Activation |
| OBS-006 | Delivery date and return rule before "Add to cart" | Typical task | Activation |
| OBS-007 | Flash-sale countdown and "items left" | Typical task | Activation / Revenue |
| OBS-008 | Heart icon saves items, needs login | Return features | Retention |
| OBS-009 | Share button to WhatsApp | Return features | Referral |
| OBS-010 | "Sponsored" labels on some cards | Return features | Revenue |

---

## OBS-001 — Home page promise in 5 seconds

- Date and time: 2026-11-24 [11:10]
- URL or screen: jumia.com.ng, first screen
- Environment: Android phone, Chrome, private window, not logged in
- Session: First visit
- User goal: Understand what this site offers me
- Observed fact: The first screen shows a large rotating banner with [a discount, e.g. "up to 50% off"], a search bar at the top and a row of categories. [A "Flash Sales" strip with a countdown] is visible without scrolling.
- My interpretation (hypothesis): The first message is "cheap and many choices". The search bar invites a visitor who already has a goal to start immediately.
- Effect on next action: I type "smartphone" in the search bar.
- AARRR stage: Acquisition
- Evidence file: evidence/OBS-001-home-first-screen.png
- Uncertainty / to check: Does the banner change by time of day? Check again at 18:00.

## OBS-002 — Sign-up discount pop-up

- Date and time: 2026-11-24 [11:12]
- URL or screen: jumia.com.ng, pop-up after [x] seconds
- Environment: Android phone, Chrome, private window
- Session: First visit
- User goal: Look around before deciding anything
- Observed fact: [A pop-up offers a discount / voucher for signing up or installing the app: write the exact words and amount]. It has a close (X) button.
- My interpretation (hypothesis): A small reward turns an anonymous visitor into a known user who can be contacted again later.
- Effect on next action: I close it (or I sign up — write what you really did).
- AARRR stage: Acquisition (bridge to Retention)
- Evidence file: evidence/OBS-002-signup-popup.png
- Uncertainty / to check: If no pop-up appears for you, write "not observed" and delete this card.

## OBS-003 — Official Store badge and rating count on cards

- Date and time: 2026-11-24 [11:18]
- URL or screen: jumia.com.ng search results for "smartphone"
- Environment: Android phone, Chrome, private window
- Session: Typical task
- User goal: Choose a phone I can trust is genuine
- Observed fact: [3] of the first [10] product cards show an "Official Store" label. Each card shows the star rating and the number of ratings, e.g. [4.2 (1,245)].
- My interpretation (hypothesis): The badge and the rating count answer the fear "is this fake?" before I open the product, so I open a badged phone first.
- Effect on next action: I open a card with the Official Store label.
- AARRR stage: Activation
- Evidence file: evidence/OBS-003-official-store-badge.png
- Uncertainty / to check: Do Official Store items rank higher? We can't see the ranking rule: hypothesis only.

## OBS-004 — Filters for price, brand and Official Store

- Date and time: 2026-11-24 [11:20]
- URL or screen: search results, "Filter" button
- Environment: Android phone, Chrome, private window
- Session: Typical task
- User goal: See only phones under ₦150,000
- Observed fact: The Filter panel has [price range, brand, rating, "Official Store" / "Express" options: list what you see]. After setting a price of ₦0–150,000, [number] results remain.
- My interpretation (hypothesis): Filters cut a huge catalogue down to a short list fast, so a new user reaches a decision before getting tired.
- Effect on next action: I compare 3–5 phones instead of scrolling hundreds.
- AARRR stage: Activation
- Evidence file: evidence/OBS-004-filters.png
- Uncertainty / to check: Is the number of results exact? Count the first page to check.

## OBS-005 — Verified-purchase reviews on the detail page

- Date and time: 2026-11-24 [11:23]
- URL or screen: product detail page [URL], "Customer feedback" section
- Environment: Android phone, Chrome, private window
- Session: Typical task
- User goal: Hear from people who already bought this phone
- Observed fact: The section shows [average rating, number of ratings, a bar per star level]. Reviews show [a date, a first name, and a "Verified Purchase" label: write what you really see]. [Photos in reviews: yes / no].
- My interpretation (hypothesis): Reviews from real buyers are more believable than the seller's description, so they push a doubtful buyer to "yes".
- Effect on next action: I read 2–3 low-star reviews to see the worst case.
- AARRR stage: Activation
- Evidence file: evidence/OBS-005-reviews.png
- Uncertainty / to check: How does Jumia check "verified"? Not visible: hypothesis.

## OBS-006 — Delivery date and return rule before "Add to cart"

- Date and time: 2026-11-24 [11:25]
- URL or screen: product detail page [URL], delivery box
- Environment: Android phone, Chrome, private window
- Session: Typical task
- User goal: Know when it arrives and if I can send it back
- Observed fact: A box shows [door delivery / pickup station] with an estimated date ["between 27 and 29 Nov"] after I chose [state, city], and a return line [exact words].
- My interpretation (hypothesis): Showing the date and return rule before payment removes the "will it arrive?" worry, possibly the biggest drop-off point for first-time buyers.
- Effect on next action: I press "Add to cart" (I stop before paying).
- AARRR stage: Activation
- Evidence file: evidence/OBS-006-delivery-returns.png
- Uncertainty / to check: Is the date the same for Lagos and Abuja? Change the state and compare.

## OBS-007 — Flash-sale countdown and "items left"

- Date and time: 2026-11-24 [11:30]
- URL or screen: Flash Sales page
- Environment: Android phone, Chrome, private window
- Session: Typical task
- User goal: Check if there is a cheaper phone today
- Observed fact: Each flash-sale card shows the old price crossed out, a discount %, and ["x items left" with a bar]. A timer at the top counts down [hh:mm:ss].
- My interpretation (hypothesis): Time limit + limited stock create urgency, so the user decides now instead of "later" (which often means never).
- Effect on next action: I look faster and feel pressure to decide.
- AARRR stage: Activation / Revenue
- Evidence file: evidence/OBS-007-flash-sale.png
- Uncertainty / to check: Does "items left" really go down? Reload after 30 minutes and compare.

## OBS-008 — Heart icon saves items, needs login

- Date and time: 2026-11-24 [11:35]
- URL or screen: product card, heart icon
- Environment: Android phone, Chrome, private window
- Session: Return features
- User goal: Keep this phone to decide later
- Observed fact: Tapping the heart [opens the login page / shows a message: write exactly]. After login, the item appears in ["Saved Items"].
- My interpretation (hypothesis): Saving gives a reason to come back, and requiring login lets Jumia remind the user later.
- Effect on next action: A not-logged-in visitor must sign in or lose the item.
- AARRR stage: Retention
- Evidence file: evidence/OBS-008-save-login.png
- Uncertainty / to check: Does Jumia send an email when a saved item's price drops? Check over 3 days.

## OBS-009 — Share button to WhatsApp

- Date and time: 2026-11-24 [11:38]
- URL or screen: product detail page, share icon
- Environment: Android phone, Chrome, private window
- Session: Return features
- User goal: Ask a friend's opinion before buying
- Observed fact: The share icon offers [WhatsApp, Facebook, Copy link…: list what you see]. Sharing works without logging in [yes / no].
- My interpretation (hypothesis): Buyers often ask friends before spending; one tap to WhatsApp turns that habit into free visitors for Jumia.
- Effect on next action: My friend opens the link and lands on the same product page.
- AARRR stage: Referral
- Evidence file: evidence/OBS-009-share.png
- Uncertainty / to check: Is there any reward for sharing? Not seen: write "no reward observed".

## OBS-010 — "Sponsored" labels on some cards

- Date and time: 2026-11-24 [11:40]
- URL or screen: search results for "smartphone"
- Environment: Android phone, Chrome, private window
- Session: Return features
- User goal: Compare phones fairly
- Observed fact: [2] of the first [20] cards carry a small "Sponsored" label. They look the same as other cards otherwise.
- My interpretation (hypothesis): Sellers pay Jumia to appear higher, a second income besides sales commissions.
- Effect on next action: I may open a sponsored card first because it is at the top.
- AARRR stage: Revenue
- Evidence file: evidence/OBS-010-sponsored.png
- Uncertainty / to check: Jumia's fees for sellers: check the official seller page; don't guess numbers.
