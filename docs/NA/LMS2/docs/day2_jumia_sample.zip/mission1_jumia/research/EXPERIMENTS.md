# EXPERIMENTS.md — Growth experiment hypotheses (EXP)

> **How to write this file**
> - An experiment is a **small, cheap test** of one change. Write it before building.
> - Each EXP must be based on **one or more OBS** (no evidence, no experiment).
> - Use this sentence: **If we [change], then [metric] will go up by [x]%, because [reason from OBS]. We will watch [side effect].**
> - **Metric** = one number you could really count (click rate, first-order rate, 7-day return rate).
> - **Side effect** = a number that might get worse because of your change.
> - **Success line** = the goal you choose before the test (not a fact). Add a time limit.
> - **ICE** = Impact, Confidence, Ease, each 1–10, average. Confidence is high **only with evidence**.
> - Sort by ICE: the top one is what you test first. Minimum 5 EXP.
>
> ⚠️ Teaching sample. Numbers are goals and scores we chose for practice, not Jumia data.

## Ranked list

| ID | Change (based on) | Metric | Side effect to watch | Success line | I | C | E | ICE |
|---|---|---|---|---|---|---|---|---|
| EXP-001 | Show the delivery date on the product card, not only on the detail page (OBS-006) | Card → detail click rate | Page load time | +10% in 2 weeks | 8 | 6 | 7 | 7.0 |
| EXP-002 | Show photo reviews first on the detail page (OBS-005) | Add-to-cart rate | Time on page | +5% in 2 weeks | 6 | 6 | 8 | 6.7 |
| EXP-003 | Let guests save items without logging in (OBS-008) | 7-day return visits | Login rate | +8% in 4 weeks | 7 | 5 | 6 | 6.0 |
| EXP-004 | Add a "Pay on delivery available" label to cards (OBS-006) | First-order rate | Returns and cancellations | +5% in 2 weeks | 7 | 4 | 7 | 6.0 |
| EXP-005 | Small credit when a shared link leads to a first order (OBS-009) | New buyers from shared links | Fake accounts | +15% shares in 4 weeks | 8 | 3 | 4 | 5.0 |

## Full example: EXP-001

- **Hypothesis:** If we show the delivery date on each product card, then the card → detail click rate will go up by 10%, because first-time buyers worry most about "will it arrive?" (OBS-006), and today they only see the date after opening the detail page.
- **Based on:** OBS-006 (delivery box only on the detail page), OBS-003 (cards already carry trust signals)
- **Metric:** clicks on cards ÷ cards shown
- **Side effect:** page gets slower or cards get crowded → watch load time and scroll depth
- **Success line:** +10% within 2 weeks, load time not worse than +0.5 s
- **Test design:** half of visitors see the new card (B), half the old card (A)
- **If it fails:** keep the old card; try the date only on the top 3 results

## Why ICE scores differ

- EXP-005 has high Impact but low Confidence (no OBS shows a reward works on Jumia) and low Ease (fraud checks needed), so it comes last.
- EXP-001 is first: clear evidence and easy to build.
