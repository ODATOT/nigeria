# GROWTH_LOOP.md — AARRR map and growth loop

> **How to write this file**
> **Part 1, AARRR map**
> - Put **every OBS ID** into one of the five stages (a card may appear in two).
> - Describe each stage in your own short words, then list the IDs as evidence.
> - A stage with no evidence gets **"Not observed"**. Never fill it with a guess.
> - Uneven stages are a finding, not a mistake: write one line on what it tells you.
>
> **Part 2, growth loop**
> - A funnel ends. A loop is a **circle**: what users do today brings more users or more value tomorrow.
> - Write 4–5 boxes joined by arrows. Put an **OBS ID on every arrow**. An arrow with no OBS = mark it "(hypothesis)".
> - Write **stop conditions**: what would break the circle? At least 1, ideally 3.
> - End with links you **can't see** (company data) and principles you'll **reuse** in your own service.
>
> ⚠️ Teaching sample. Uses the IDs from the sample BENCHMARK_LOG.md.

## Part 1 · AARRR map

| Stage | Question | What I saw on Jumia | Evidence |
|---|---|---|---|
| Acquisition | Where do users first come in? | Discount banner and search bar first; sign-up discount pop-up | OBS-001, OBS-002 |
| Activation | What is the first value moment? | Trust **before** the click: Official Store badge, rating counts, verified reviews, delivery date and returns before paying; filters; flash-sale urgency | OBS-003, 004, 005, 006, 007 |
| Retention | Why do they come back? | Saved items (login needed) | OBS-008 |
| Referral | What brings other users? | Share to WhatsApp | OBS-009 |
| Revenue | Who pays, for what? | Product sales; sellers pay for "Sponsored" places (hypothesis) | OBS-007, OBS-010 |

Not observed: email or app notifications, loyalty points, seller dashboard (we did not log in long enough or open the seller side).

**What the map tells me:** 5 of 10 cards are Activation. For a first-time buyer, Jumia invests most in **trust**. The weakest stage we saw is Retention.

## Part 2 · Growth loop

```text
[Buyers order and receive items]                      (OBS-006)
   → [They leave ratings and reviews]                  (OBS-005)
   → [Cards show high rating counts = trust]           (OBS-003)
   → [More first-time visitors dare to buy]            (OBS-003, OBS-006)
   → [More orders, more reviews]                       (back to the start)
```

Second loop, seller side (hypothesis, not observed directly):
more buyers → more sellers join and pay for Sponsored places (OBS-010) → more choice and lower prices → more buyers.

**Strongest three pieces of evidence:** OBS-003, OBS-005, OBS-006
(anyone can repeat them in two minutes, and together they show trust → purchase → review).

## Stop conditions

1. **Fake or bought reviews:** ratings stop meaning anything, so trust disappears.
2. **Late or failed deliveries:** angry reviews scare away new buyers.
3. **Too many Sponsored cards:** buyers can't find the best product and leave.

## Links we can't see

- How many buyers actually leave a review (company data).
- How search ranking works (we see results, not rules).
- Whether sellers really pay for Sponsored places, and how much (check the official seller page).

## Principles for my own service

- Show trust **before** asking for money (OBS-003, OBS-006).
- Let real buyers speak for the product (OBS-005).
- Make sharing one tap into WhatsApp (OBS-009).

## Must not copy

- Jumia's name, logo, colours, images or text (copyright and trademarks).
- Real reviews or seller data. Use made-up sample data in your build.
