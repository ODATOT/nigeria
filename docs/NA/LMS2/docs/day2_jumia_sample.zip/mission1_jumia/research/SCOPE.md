# SCOPE.md — What I am studying

> **How to write this file**
> - Write **one service, one user, one task**. Small scope = deep evidence.
> - **Service:** the exact site or app and how you use it (browser or app, phone or laptop).
> - **User:** a real type of person, not "everyone". Say who they are and what they worry about.
> - **Task:** one job with a clear end. Use a verb: "find…", "decide…", "send…". Stop before paying.
> - **One-sentence test:** if you can't say it in one sentence, the scope is too big.
> - Lines in `> quote blocks` are guidance. Delete them in your own file.
>
> ⚠️ Teaching sample. `[brackets]` = fill in from your own screen.

## One sentence

A first-time online buyer in Abuja uses Jumia Nigeria on a phone browser to find and decide on a smartphone under ₦150,000.

## Details

| Item | My choice |
|---|---|
| Service | Jumia Nigeria — jumia.com.ng |
| Device and environment | Android phone, Chrome, private window (not logged in) for sessions 1–2; logged in for session 3 |
| User | Budget-conscious first-time online buyer, 20–30 years old, worried about fake products and late delivery |
| Task | Find a smartphone under ₦150,000 and decide whether to trust and buy it (stop before payment) |
| Out of scope | Payment, seller registration, Jumia Food, the mobile app |

## Sessions planned

| Session | Purpose | Time | Date |
|---|---|---|---|
| 1. First visit | 5-second impression, promise, main button | 20–30 min | 24 Nov 2026 |
| 2. Typical task | Clicks, scrolls, trust elements, where I want to leave | 20–45 min | 24 Nov 2026 |
| 3. Return features | What brings me back: saved items, share, notifications | 30 min | [24–25 Nov 2026] |

## Rules I follow

- Public screens and official pages only. No hacking, no scraping, no private APIs.
- No copying of logos, images, text or code.
- Blur other people's names, phone numbers and photos in screenshots.
- AI does not write my observations. My eyes do.
